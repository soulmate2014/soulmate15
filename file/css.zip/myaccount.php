<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<link href="css/style1.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
</head>

<body>
		<div class="header"><img src="img/images/images/about_02.png" />
    <div class="navbar-wrapper">
    		<div class="container">

      
              <div class="span2 border" data-original-title="" title=""><i class="icon-user"></i><a href="#">NRI LOGIN</a></div>
               <div class="span2 border" data-original-title="" title=""><i class="icon-user"></i><a href="#">CELEBRITIES LOGIN</a></div>
               <div class="span1" data-original-title="" title=""></div>
               <div class="span3" data-original-title="" title=""><img src="img/images/logo_06.png"></div>
   
               <div class="span5 offset0" data-original-title="" title="">
      	<form class="form-inline">
               <div class="span2 forgot"><input type="text" class="input-medium email" placeholder="Email">
                 &nbsp;<a href="#">forgot password?</a> </div>
               <input type="password" class="input-medium email" placeholder="Password">
               <button type="submit" class="btn">Log in</button>
 		</form>
               </div>

      </div>
    </div>
   </div>
   <div class="row-fluid menu ">
    <div class="container">
    <div class="navbar">
<div class="navbar-inner">
            <div class="container">
            <div class="span3" data-original-title="" title=""></div>
              <ul class="nav">
                <li ><a href="#">HOME</a></li>
                <li><a href="#">ABOUTUS</a></li>
                <li class="active"><a href="#">MY ACCOUNT</a></li>
                <li><a href="#">REGISTER</a></li>
                <li><a href="#">SEARCH</a></li>
                <li><a href="#">UP GRADE</a></li>
                <li><a href="#">CONTACT US</a></li>
                <li style="border:none;"><a href="#">HELP</a></li>
              </ul>
              <div class="span3" data-original-title="" title=""></div>
            </div>
          </div>
          </div>
          </div>
        </div>
   	<div class="center">
           <div class="row-fluid content">
				<div class="container">
    				<div class="span12">
                    	 <h2>MY ACCOUNT </h2>
                    		
                            
                            <div class="span7 ">
                            <div class="profile">
                            	<div class="span12">
                                	<div class="span4 "><img src="img/images/images/my-account_05.png" /></div>
                            		<div class="span8">
                                    	<div class="loader"><p>your profile is </p>
                                    		<div class="span3"><div class="progress">
  <div class="bar" style="width: 70%;">55%</div>
</div></div>
                                      <p>completed</p>     
                                        
                                        </div>
                                    </div>
								</div> 
                                </div>                           
        					
                       
                           <div class="personal">
                            <div class="span11">
                            <h2>Personal Information</h2>
                             <div class="personal">
                          <div class="span10">
                          <div class="span12" >
                          
                          <ul class="nav">
                         <li style="border:none;margin-top:10px;"> <img src="img/images/images/images/icon_07.jpg" /></li>
                <li ><h3>myself</h3></li>
                <li style="border:none;" ><h3>edit</h3></li>
                            </ul>
                            </div>
                            </div>
                             </div>
                            <div class="paragraph">
                              <div class="span12">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy </p>
                             </div>
                            </div> 
               </div>
                    </div>
                    
                    <div class="personal">
                            <div class="span11">
                           
                             <div class="personal">
                          <div class="span10">
                          <div class="span12" >
                         
                          <ul class="nav">
                 <li style="border:none;margin-top:10px;"> <img src="img/images/images/images/icon-2_11.jpg" /></li>          
                <li ><h3>Basic Details</h3></li>
                <li style="border:none;" ><h3>edit</h3></li>
                            </ul>
                            </div>
                            </div>
                             </div>
                            <div class="tble ">
                              <div class="span12">
                    <table class="new2 ">
                   
  							<tr >
                            	<td >profile created for :</td>
                                <td >son</td>
                                <td class="new">name:</td>
                                <td >jaison k mathew</td>
                               
                                
                              </tr>
                              <tr>
                                <td>body Type/Completion :</td>
                                <td>slim</td>
                                 <td class="new">age :</td>
                                <td>24</td>
                                
                                </tr>
                           	<tr>
                            	<td>Physical Status :</td>
                               <td>normal</td>
                               <td class="new">height :</td>
                                <td>5.8</td>
                             </tr>
                             <tr> 
                               <td>Weight :</td>
                               <td>70</td>
                               <td class="new">Mother Tounge:</td>
                                <td>malayalam</td>
                             </tr>
                   </table >
                   
                             
                             
						</div>
                            </div> 
                             </div>
                  
                    </div>
                    
                    
                    
                    
                    
                    
 <div class="personal">
                            <div class="span11">
                           
                             <div class="personal">
                          <div class="span10">
                          <div class="span12" >
                          
                          <ul class="nav">
                 <li style="border:none;margin-top:10px;"> <img src="img/images/images/images/icon-2_16.jpg" /></li> 
                <li ><h3>Religious Information</h3></li>
                <li style="border:none;" ><h3>edit</h3></li>
                            </ul>
                            </div>
                            </div>
                             </div>
                            <div class="tble">
                              <div class="span12">
                    <table class="new2 ">
                   
  							<tr >
                            	<td >Religion :</td>
                                <td >christain</td>
                             
                              </tr>
                              <tr>
                                <td>Caste /Sub Caste :</td>
                                <td>jacobite</td>
                                
                                </tr>
                           	<tr>
                            	<td>Star </td>
                               <td>not mentioned</td>
                               
                             </tr>
                             <tr> 
                               <td>hudha Jdakam :</td>
                               <td>not mentioned</td>
                              
                             </tr>
                   </table >
                   
                             
                             
						</div>
                            </div> 
                             </div>
                  
                    </div>                   
                    
                    
                    <div class="personal">
                            <div class="span11">
                           
                             <div class="personal">
                          <div class="span10">
                          <div class="span12" >
                          
                          <ul class="nav">
                 <li style="border:none;margin-top:10px;"> <img src="img/images/images/images/icon-3_16.jpg" /></li> 
                <li ><h3>Location</h3></li>
                <li style="border:none;" ><h3>edit</h3></li>
                            </ul>
                            </div>
                            </div>
                             </div>
                            <div class="tble">
                              <div class="span12">
                    <table class="new2 ">
                   
  							<tr >
                            	<td >Country :</td>
                                <td >india</td>
                        
                                <td class="new">State :</td>
                                <td>kerala</td>
                                
                                </tr>
                           	<tr>
                            	<td>City:</td>
                               <td>kottayam</td>
                         
                               <td class="new">citizenship:</td>
                               <td>indian</td>
                              
                             </tr>
                   </table >
                   
                             
                             
						</div>
                            </div> 
                             </div>
                  
                    </div>
                    



<div class="personal">
                            <div class="span11">
                           
                             <div class="personal">
                          <div class="span10">
                          <div class="span12" >
                          
                          <ul class="nav">
                 <li style="border:none;margin-top:10px;"> <img src="img/images/images/images/icon-4_16.jpg" /></li> 
                <li ><h3>Profesional Information</h3></li>
                <li style="border:none;" ><h3>edit</h3></li>
                            </ul>
                            </div>
                            </div>
                             </div>
                            <div class="tble">
                              <div class="span12">
                    <table class="new2 ">
                   
  							<tr >
                            	<td >Education :</td>
                                <td >b-tech</td>
                                <td class="new">Occupation In Detail :</td>
                                <td >b-tech(cs)</td>
                               
                                
                              </tr>
                              <tr>
                                <td>college:</td>
                                <td>cmc</td>
                                 <td class="new">Employed In :</td>
                                <td>eranakulam</td>
                                
                                </tr>
                           	<tr>
                            	<td>Occupation :</td>
                               <td>software developer</td>
                               <td class="new">Anual Income :</td>
                                <td>20000</td>
                             </tr>
                            
                   </table >
                   
                             
                             
						</div>
                       </div> 
                       </div>
                  </div>





<div class="personal">
                            <div class="span11">
                           
                             <div class="personal">
                          <div class="span10">
                          <div class="span12" >
                          
                          <ul class="nav">
                 <li style="border:none;margin-top:10px;"> <img src="img/images/images/images/icon-5_16_16.jpg" /></li> 
                <li ><h3>Family Details</h3></li>
                <li style="border:none;" ><h3>edit</h3></li>
                            </ul>
                            </div>
                            </div>
                             </div>
                            <div class="tble">
                              <div class="span12">
                    <table class="new2 ">
                   
  							<tr >
                            	<td >Family Value :</td>
                                <td >son</td>
                                <td  class="new">No:Of Brothers(s):</td>
                                <td >1</td>
                               
                                
                              </tr>
                              <tr>
                                <td>Family Status :</td>
                                <td>medium</td>
                                 <td class="new">Mother Status :</td>
                                <td>homemaker</td>
                                
                                </tr>
                           	<tr>
                            	<td>Father Status:</td>
                               <td>business</td>
                               <td class="new">No:Of Sister(s):</td>
                                <td>1</td>
                             </tr>
                           
                   </table >
                   
                             
                             
						</div>
                       </div> 
                       </div>
                  </div>


                    
                    
                    
                    
</div>
           		
                 <div class="span5">
                 			
                            
                            <div class="search">
                            	<div class="span12">
                                <h3>Search by ID</h3>
                                <div class="span11">
                                
                                <form class="navbar-form pull-left form-search">
                                <input type="text" class="form-control">
       				 <button class="btn">Search</button>
  						</form>
                            	</div>	
								
                                </div>
                              </div>
                              
                              
                              
                              
                               <div class="matches">
                            	<div class="span12">
                                	<h3>Your matches</h3>
                                		<div class="span10">
                                        	<div class="span11">  <img src="img/images/images/my-account_03.jpg" /></div>
                                        <div class="span9">
                                        <h4>Tharunima</h4>
                                        <h5>S189599</h5>
                                        <h5>Trichur</h5>
                                        </div>
                                        </div>
                                <div class="span5"> 
       				<button type="submit" style="background-color:#FFF;" class="btn1 btn-large match">More</button>

                                </div>
                             
                                </div>
                                </div>
                                
                                <div class="personal">
                            <div class="span11">
                           
                             <div class="personal">
                          <div class="span12">
                          <div class="span12" >
                         <div class="adjest"> 
                          <ul class="nav">
                 <li style="border:none;margin-top:10px;"> <img src="img/images/images/images/icon_07.jpg"/></li> 
                <li ><h3>Basic & Religious Preferences</h3></li>
                <li style="border:none;" ><h3>edit</h3></li>
                            </ul>
                            </div>
                            </div>
                            </div>
                             </div>
                            <div class="tble">
                              <div class="span12">
                    <table class="new2 ">
                   
  							<tr >
                            	<td >Age :</td>
                                <td >24</td>
                             
                              </tr>
                              <tr>
                                <td>height :</td>
                                <td>5.8</td>
                                
                                </tr>
                           	<tr>
                            	<td>Marital Status :
.</td>
                               <td>never married</td>
                               
                             </tr>
                             <tr> 
                               <td>Physical Status :</td>
                               <td>normal</td>
                              
                             </tr>
                             <tr> 
                               <td>Religion :</td>
                               <td>christain</td>
                              
                             </tr>
                             <tr> 
                               <td>Mother Toungue :</td>
                               <td>mayalam</td>
                              
                             </tr>
                             <tr> 
                               <td>Cast / Religion :</td>
                               <td>jacobite</td>
                              
                             </tr>
                              <tr> 
                               <td>Star :</td>
                               <td>not mentioned</td>
                              
                             </tr>
                   </table >
                   
                             
                             
						</div>
                            </div> 
                             </div>
                  
                    </div>
                    
                    
                    <div class="personal">
                            <div class="span11">
                           
                             <div class="personal">
                          <div class="span12">
                          <div class="span12" >
                          <div class="adjest"> 
                          <ul class="nav">
                 <li style="border:none;margin-top:10px;"> <img src="img/images/images/images/icon-4_16.jpg" /></li> 
                <li ><h3>Professional Preferences</h3></li>
                <li style="border:none;" ><h3>edit</h3></li>
                            </ul>
                            </div>
                            </div>
                            </div>
                             </div>
                            <div class="tble">
                              <div class="span12">
                    <table class="new2 ">
                   
  							<tr >
                            	<td >Education :</td>
                                <td >b-tech</td>
                             
                              </tr>
                              <tr>
                                <td>Occupation :</td>
                                <td>software developer</td>
                                
                                </tr>
                           	<tr>
                            	<td>Annual Income :
</td>
                               <td>20000</td>
                               
                             </tr>
                            
                   </table >
                   
                             
                             
						</div>
                            </div> 
                             </div>
                  
                    </div>
                    
                    
                    <div class="personal">
                            <div class="span11">
                           
                             <div class="personal">
                          <div class="span12">
                          <div class="span12" >
                          <ul class="nav">
                          <li style="border:none;margin-top:10px;"> <img src="img/images/images/images/icon-6_17.jpg" /></li> 
               <li style="border:none;"><h3>Location Preferences</h3></li>
               				</ul>
                          
                            </div>
                            </div>
                             </div>
                            <div class="tble">
                              <div class="span12">
                    <table class="new2 ">
                   
  							<tr >
                            	<td >Country:</td>
                                <td >india</td>
                             
                              </tr>
                              <tr>
                                <td>State :</td>
                                <td>kerala</td>
                                
                                </tr>
                           	<tr>
                            	<td>City :
</td>
                               <td>kottayam</td>
                               
                             </tr>
                            
                   </table >
                   
                             
                             
						</div>
                            </div> 
                             </div>
                  
                    </div>
  
  
  
   </div>
   </div>
   
   </div>
   </div>
   </div>
   
   
   
   

  <div class="row-fluid footer">
           <div class="container">
    <div class="span6 footer_manu feutured1">
           <a href="#">HOME</a> / 
           <a href="#">ABOUTUS</a> /
            <a href="#">MY ACCOUNT</a> /
             <a href="#">REGISTER</a> / 
             <a href="#">SEARCH</a>  / 
             <a href="#">UP GRADE</a> / 
             <a href="#">CONTACT US</a> / 
             <a href="#">HELP</a>
             </div>
             <div class="span3"></div>
             <div class="span3 feutured1"> <div class="span4"><label class="control-label" for="inputEmail">FOLLOW US </label></div>
                               <ul> <li><a href="#"><img src="img/images/facebook_25.jpg"></a></li>
                                <li><a href="#"><img src="img/images/twitter_25.jpg"></a></li>
                                <li><a href="#"><img src="img/images/google_25.jpg"></a></li> </ul>
                              
                            </div>
             </div>
             </div>
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
        
        
           
</body>
</html>
