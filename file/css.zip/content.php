<div class="row-fluid">
        <div class="span4"></div><div class="span1"></div>
         <div class="span4 butten"><div class="control-group"><button type="submit" style="background-color:#FFF;" class="btn1 btn-large">REGISTER FREE</button>
    <div class="controls">
    
      
    </div>
  </div></div>
          <div class="span4"></div>
      </form>
     		</div>
     </div>
      <div class="row-fluid feutured"><div class="container">
        <div class="row show-grid">
                <div class="span3" data-original-title="" title=""></div>  <div class="span2" data-original-title="" title=""></div><div class="span5 feutured" data-original-title="" title=""><h3>PROFILE VIEWS</h3>
                </div>
          </div>
          <div class="row show-grid">
          
          	<div class="container fet">
            <div class="span2"><img src="img/images/fet1_23.jpg"><h5 class="disc">ID:EJK12586
27,CASTE,PLACE
CIVIL ENGINEER</h5>
<div class="span2"></div><button type="submit" class="btn-danger">View Profile</button></div>
            <div class="span2"><img src="img/images/fet1_23.jpg"><h5 class="disc">ID:EJK12586
27,CASTE,PLACE
CIVIL ENGINEER</h5>
<div class="span2"></div><button type="submit" class="btn-danger">View Profile</button>
</div>
            <div class="span2"><img src="img/images/fet1_23.jpg"><h5 class="disc">ID:EJK12586
27,CASTE,PLACE
CIVIL ENGINEER</h5>
<div class="span2"></div><button type="submit" class="btn-danger">View Profile</button>
</div>
            <div class="span2"><img src="img/images/fet1_23.jpg"><h5 class="disc">ID:EJK12586
27,CASTE,PLACE
CIVIL ENGINEER</h5>
<div class="span2"></div><button type="submit" class="btn-danger">View Profile</button>
</div>
            <div class="span2"><img src="img/images/fet1_23.jpg"><h5 class="disc">ID:EJK12586
27,CASTE,PLACE
CIVIL ENGINEER</h5>
<div class="span2"></div><button type="submit" class="btn-danger">View Profile</button>
</div>
            <div class="span2"><img src="img/images/fet1_23.jpg"><h5 class="disc">ID:EJK12586
27,CASTE,PLACE
CIVIL ENGINEER</h5>
<div class="span2"></div><button type="submit" class="btn-danger">View Profile</button>
</div>
          		</div>
          	</div>
            <div class="row show-grid">
          	<div class="container">
            <div class="span6 happy_feed">
            <div class="span9 happy_feutured" data-original-title="" title=""><h3 class="happy_head">HAPPY FEEDBACK</h3></div>
            <div class="span6"><img src="img/images/feedback_image_07.jpg">
            </div>
            <div class="span5">
            <h4 class="feed_head">THARUN & THAMANNA
JAN 23 / 2014</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                                 </p>
                                                 <button type="submit" class="btn-info">More</button>
            </div>
        
                </div>
             
          <div class="span6 happy_feed plans">
            <div class="span9 happy_feutured" data-original-title="" title=""><h3 class="happy_head1">OUR PLANS</h3></div>
            <div class="span6"><img src="img/images/plans_09.jpg">
            </div>
            <div class="span5">
            <h4 class="feed_head">PREMIUM PLUS</h4>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.labore et dolore magna aliqua.
                                                 </p>
                                                 
                                                 <button type="submit" class="btn-info">More</button>
            </div>
        
                </div>
          		</div>
          	</div>
          </div>
          </div>
          