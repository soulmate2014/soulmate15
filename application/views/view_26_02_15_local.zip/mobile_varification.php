<?php $this->load->view('profile_header');?>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"> </script>
<script type="text/javascript" src="<?php echo base_url() ?>file/js/script.js"></script>
<link href="<?php echo base_url() ?>file/css/popup.css" rel="stylesheet" type="text/css" media="all" />
<div class="row-fluid content">
	<div class="container">
            <div class="span12 mob">
            	<div class="span10 mob1">
             <?php if(isset($error)){ ?>
						<h3> <?php echo $error; ?></h3>
					<?php }?>
            		<div class="span7 mob2">
                   
                    <h3>Congragulations, you have succesfully registered in
soulmate matrimony</h3></div>
<div class="span8 mob3">
 <p>You can log in with this Matrimony id: S898985,Mobile no or your E-mail id.
A confirmation mail with log in details has been sent to you.</p>        </div>           
                   </div>
 <div class="span10 mob4">                  
       <h1>Verify your mobile no to active your profile</h1>
  </div>
  <div class="span10 mob5">      
       
       <p>it is mandatory to verify your mob no,otherwise your profile will not be visible to other members</p>
 </div>                       
 <div class="span10 mob6">
 
 					<div class="span8 mob7" style="margin-bottom:20px;">
                    <h1>Verify your mobile no through Sms</h1>
                    
                    </div>
                    
                    <div class="span8 mob8" style="margin-bottom:20px;">
 <h3>An sms verification PIN has been sent to your mobile</h3>
 					</div> 
               
  <div class="span6">
  <form action="<?php echo base_url(); ?>index.php/mobile_varification/varification1" method="post">
   <input type="hidden" name="mobile" value="<?php echo $mobile;?>" style="height:30px"  />
    <input type="hidden" name="user_id" value="<?php echo $user_id;?>" style="height:30px"  />
     <input type="hidden" name="email" value="<?php echo $email; ?>" style="height:30px"  />
  <input type="text" name="otp" style="height:30px"  /><button type="submit" class="btn">Verify</button>
  </form>
  </div>
 <!-- <div class="span4">
  <input type="text" name=""  value="9895989598" />
  <button class="btn"><a href="#" class="topopup9" style="text-decoration:none; color:inherit;">Edit no</a></button>
    </div>    -->            
      
      
      
 
 
 
 
 <!--<div id="toPopup9"> 
    	
        <div class="close9"></div>
       
		<div id="popup_content9"> <!--your content start-->
        <!--<h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div>--> <!--toPopup end-->-->
<!--    
	<div class="loaderr9"></div>
   	<div id="backgroundPopup9"></div>-->
               
      
      
      
      
      
      
                    
<!--  <div class="span9 mob11">
 <h3>You will receive sms in few second,if dont click to resend the PIN</h3>
  </div>                   
  <div class="span4 mob13"><button type="submit" class=" btn-large mob12 ">Resend pin</button></div>                  
                        
 </div>-->
 <div class="span8 mob14">          
   <h4>Once your mobile no is verified <a href="#">click here</a> to start your partner search</h4> </div>            
            </div>
    </div>
</div>
</body>
</html>