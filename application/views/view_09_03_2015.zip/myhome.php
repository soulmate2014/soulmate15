<?php if($this->session->userdata('logged_in'))
 {
	 $session_data = $this->session->userdata('logged_in');
		$soul_id= $session_data['user_id'];
	 
	 ?>
<?php $this->load->view('header'); ?>
<style>
.row-fluid.recommends8 .container .span12 .span8 .nav.nav-tabs.ad.mclr.recommends1 li.active{
	background-color:#991248;
}
.row-fluid.recommends8 .container .span12 .span8 .nav.nav-tabs.ad.mclr.recommends1 li active.a:active{
	background-color:#991248;
}
</style>

<div class="row-fluid recommends8">
<div class="container">
<div class="span12 ">


<div class="span8 recommends2">
 <ul class="nav nav-tabs ad mclr recommends1" role="tablist">
    <li role="presentation" class="active "><a href="#home" aria-controls="home" role="tab" data-toggle="tab" >
    <div class="recommends"><span><?php 
	if(count($query1)>0)
	{
		echo count($query1);
		};?></span> <br />New matches</div></a></li>
    	<li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab" ><div class="recommends"><span><?php echo $profile->num_rows(); ?></span> <br />Yet to be viewed</div></a></li>
    	<li role="presentation" ><a href="#viewed" aria-controls="messages" role="tab" data-toggle="tab" ><div class="recommends"><span><?php echo $viewed->num_rows(); ?></span> <br />Viewed & not contacted</div></a></li>
   		<li role="presentation" ><a href="#shortlist" aria-controls="messages1" role="tab" data-toggle="tab" ><div class="recommends"> <span><?php echo $shortlisting->num_rows(); ?></span> <br />Shortlisted my profile</div></a></li>
    	<li role="presentation" ><a href="#like" aria-controls="messages2" role="tab" data-toggle="tab" ><div class="recommends"><span> <?php echo $like->num_rows(); ?></span><br />Liked profile</div></a></li>
    
  </ul>
<script>
document.getElementById("myDiv").style.marginLeft = "0px";
</script>

  <!-- Tab panes -->
  <div class="tab-content mclr1 bg">
    <div role="tabpanel" class="tab-pane active" id="home">
    <?php foreach($query1 as $row)
	{ ?>
 
    	<div class="span12 mdiv " style="margin-left:0px;" >
			<div class="span12 prof1">
            	<div class="span12">
                	 <?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]=  'S2078769';
 }
 if (in_array($row->user_id, $blocked)||($blocked===NULL)){
		?>
                    <span class="v1"><a href="#"><?php echo $row->name; ?> (<?php echo $row->user_id; ?>)</a> <i class=" icon-large icon-ban-circle"></i></span><br />
                    <?php } else { ?>
                    <span class="v1"><a href="#"><?php echo $row->name; ?> (<?php echo $row->user_id; ?>)</a></span><br />
                    
                    <?php } ?>
                  
                </div>
                <div class="span12">
                    <div class="span3 view1" style="width:150px;">
                       <?php if($row->file_name=='')
									{ ?><img class="profile_thumb" src="<?php echo base_url();?>file/img/noimg.jpg"  />
                                    <?php }
									else
									{
										?>
                                    
                                    <img class="profile_thumb" src="<?php echo base_url();?>uploads/<?php echo  $row->file_name; ?>"><?php } ?>
                    </div>
                        <div class="span5" style=" width:43.5%;">
                            <div class="loader1 mclr2">
                                <p>
                                	<img src="<?php echo base_url(); ?>file/img/p1_03.jpg">   View Mobile No/sms 
                                </p>
                                <p> 
                                	<img src="<?php echo base_url(); ?>file/img/p2_03.jpg">  Request Horoscope			</p>    
                                   	<div class="span12 mnn">
                                      <?php  echo $row->about_us; ?> <br /> 
 <br />
 									</div>

									<div class="span12">
                                   
						<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
  <?php
 if ($intrested->num_rows() >0)
 {
  foreach($intrested->result() as $intrest) {
	 $int[]=  $intrest->intrested_id;
 }}
 else
 {
 $int[]= '10000';
 }
 if (in_array($row->user_id, $int)||($int===NULL)){
		?>


       Intrest Send <?php } else {?>
         <a href="<?php echo base_url(); ?>index.php/status/intrest/<?php  echo $row->user_id; ?>" style="text-decoration:none; color:inherit;">

        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" />
        <?php }?>
        
        
 <?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]= 'S2078769';
 }
 if (in_array($row->user_id, $blocked)||($blocked===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/unblock/<?php  echo $row->user_id; ?>" style="text-decoration:none; color:inherit;"> <input style="background-color:#999;"   class=" btn1 btn-small match mbtn" type="button" value="Blocked" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/block/<?php  echo $row->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" /></a>
        <?php  }?>
 
 <?php
 if ($shortlist->num_rows() >0)
 {
  foreach($shortlist->result() as $short) {
	 $shortlisted[]=  $short->shortlisted_id;
 }}
 else
 {
 $shortlisted[]=  '11111';
 }
 if (in_array($row->user_id, $shortlisted)||($shortlisted===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/shortlisted/<?php  echo $row->user_id; ?>" style="text-decoration:none; color:inherit;"> <input class="btn1 btn-small match mbtn" style="background-color:#999;" type="button" value="shortlisted" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/shortlist/<?php  echo $row->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="shortlist" /></a>
        <?php  }?>
</form>
 </span>
<div id="toPopup10"> 
    	
        <div class="close10"></div>
        	<div id="popup_content10"> <!--your content start-->
        	    <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            	</p>
            	<div class="span4">
 				</div>  
         	<a href="#"><input type="button" class="ppbutton" value="update"/></a>
        	</div> <!--your content end-->
    
   		</div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
<div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you Wan't to block this user.click update
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                                  <table>
                                <tr>
                                  <td width="120px;">Profile Created For
                                    </td>
                                  <td>
                                  :&nbsp;
                                  </td>
                                  <td>
									<strong><?php echo $row->profile_for; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Age, Height
                                    </td>
                                    <td>
                                  :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $row->age; ?> Yrs, <?php echo $row->height; ?> Cms</strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Religion
                                    </td>
                                    <td>
                                 :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $row->religion_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Caste, Sub Caste</td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $row->cast_name; ?>,<?php echo $row->subcast; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Star
                                    </td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $row->star_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td valign="top">Location 
                                    </td>
                                    <td valign="top">
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $row->city; ?>, <?php echo $row->state; ?>, <?php echo $row->country; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                <tr>
                                  <td valign="top">Education
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $row->education_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                
                                <tr>
                                  <td valign="top">Occupation
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $row->occupation_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                 <tr>
                                    <td>Gender
                                    </td>
                                    <td>
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $row->gender; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                        	</table>
                            <br />
<a href="<?php echo base_url();?>index.php/individual/profile/<?php echo $row->user_id; ?>"><strong>View Full Profile</strong></a>
  <br />
  &nbsp;
</div>
					</div>			</div>
                    
                    
                     


</div>
   
	<?php }
	?>
    <div class="span12 recommends5">                                           
  <div class="span8 recommends6">
<?php if(count($query1)>9){ ?>
<div class="span4 recommends7"><a href="<?php echo base_url(); ?>index.php/searching/newmatches_all">
  <button type="submit" style="width: 150px;" class="btn1 btn-large match">View all</button>
</a></div>
<?php } else{ echo ""; }?>

</div>     
  </div>
</div>
        
         
         
         
         
         
         <div role="tabpanel" class="tab-pane" id="profile">	
          <?php foreach($profile->result() as $pro){ ?>
    <div class="span12 mdiv " style="margin-left:0px;" >

                            	<div class="span12 prof1" style="margin-left:0px;">
                                	<div class="span12">
                                    <?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]=  'S2078769';
 }
 if (in_array($pro->user_id, $blocked)||($blocked===NULL)){
		?>
                    <span class="v1"><a href="#"><?php echo $pro->name; ?> (<?php echo $pro->user_id; ?>)</a> <i class=" icon-large icon-ban-circle"></i></span><br />
                    <?php } else { ?>
                    <span class="v1"><a href="#"><?php echo $pro->name; ?> (<?php echo $pro->user_id; ?>)</a></span><br />
                    
                    <?php } ?>
                                    
                                 </div>
                                 	<div class="span12" style="margin-left:0px;">
                                    <div class="span3 view1 " style="width:150px;">
                                   
                                    <?php if($pro->file_name=='')
									{ ?><img class="profile_thumb" src="<?php echo base_url();?>file/img/noimg.jpg" />
                                    <?php }
									else
									{
										?>
                                    
                                    <img class="profile_thumb" src="<?php echo base_url();?>uploads/<?php echo  $pro->file_name; ?>"><?php } ?></div>
                            		  <div class="span5" style=" width:43.5%;">
                                    <div class="loader1 mclr2">
                                    <p>
                                	<img src="<?php echo base_url(); ?>file/img/p1_03.jpg">   View Mobile No/sms 
                                </p>
                                <p> 
                                	<img src="<?php echo base_url(); ?>file/img/p2_03.jpg">  Request Horoscope			</p>   
                                     
                                  
                                     <div class="span12 mnn">
                                    <?php echo  $pro->about_us; ?><br /> 
 <br /></div>

<div class="span12">
<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
 
  <?php
 if ($intrested->num_rows() >0)
 {
  foreach($intrested->result() as $intrest) {
	 $int[]=  $intrest->intrested_id;
 }}
 else
 {
 $int[]= '10000';
 }
 if (in_array($pro->user_id, $int)||($int===NULL)){
		?>


       Intrest Send <?php } else {?>
         <a href="<?php echo base_url(); ?>index.php/status/intrest/<?php  echo $pro->user_id; ?>" style="text-decoration:none; color:inherit;">

        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" />
        <?php }?>

<?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]=  'S2078769';
 }
 if (in_array($pro->user_id, $blocked)||($blocked===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/unblock/<?php  echo $pro->user_id; ?>" style="text-decoration:none; color:inherit;"> <input style="background-color:#999;"   class=" btn1 btn-small match mbtn" type="button" value="Blocked" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/block/<?php  echo $pro->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" /></a>
        <?php  }?>
 
 <?php
 if ($shortlist->num_rows() >0)
 {
  foreach($shortlist->result() as $short) {
	 $shortlisted[]=  $short->shortlisted_id;
 }}
 else
 {
 $shortlisted[]=  '11111';
 }
 if (in_array($pro->user_id, $shortlisted)||($shortlisted===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/shortlisted/<?php  echo $pro->user_id; ?>" style="text-decoration:none; color:inherit;"> <input class="btn1 btn-small match mbtn" style="background-color:#999;" type="button" value="shortlisted" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/shortlist/<?php  echo $pro->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="shortlist" /></a>
        <?php  }?>
</form>
 </span>
  <div id="toPopup10"> 
    	
        <div class="close10"></div>
       
		<div id="popup_content10"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
    
    
    
    
    
    
    
    
    <div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                               <table>
                                <tr>
                                  <td width="120px;">Profile Created For
                                    </td>
                                  <td>
                                  :&nbsp;
                                  </td>
                                  <td>
									<strong><?php echo $pro->profile_for; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Age, Height
                                    </td>
                                    <td>
                                  :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $pro->age; ?> Yrs, <?php echo $pro->height; ?> Cms</strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Religion
                                    </td>
                                    <td>
                                 :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $pro->religion_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Caste, Sub Caste</td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $pro->cast_name; ?>,<?php echo $pro->subcast; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Star
                                    </td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $pro->star_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td valign="top">Location 
                                    </td>
                                    <td valign="top">
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $pro->city; ?>, <?php echo $pro->state; ?>, <?php echo $pro->country; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                <tr>
                                  <td valign="top">Education
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $pro->education_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                
                                <tr>
                                  <td valign="top">Occupation
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $pro->occupation_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                 <tr>
                                    <td>Gender
                                    </td>
                                    <td>
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $pro->gender; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                        	</table>
<br />
<a href="<?php echo base_url();?>index.php/individual/profile/<?php echo $pro->user_id; ?>"><strong>View Full Profile</strong></a>
</div>
					</div>			</div>
                    
                    
                     


</div>
<?php } ?>

<div class="span12 recommends5">                                           
  <div class="span8 recommends6">
<?php if(count($profile)>10){ ?>
<div class="span4 recommends7"><a href="<?php echo base_url(); ?>index.php/searching/yettobeviewed/<?php echo $soul_id ?>">
<button type="submit" style="width: 150px;" class="btn1 btn-large match">View all</button>
</a></div>
<?php } ?>

</div>     
  </div>

 		</div>
        
        
        <div role="tabpanel" class="tab-pane" id="viewed">	
         <?php foreach($viewed->result() as $view) { ?>
    <div class="span12 mdiv " style="margin-left:0px;" >

                            	<div class="span12 prof1">
                                	<div class="span12">
                                    
                                      <?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]=  'S2078769';
 }
 if (in_array($view->user_id, $blocked)||($blocked===NULL)){
		?>
                    <span class="v1"><a href="#"><?php echo $view->name; ?> (<?php echo $view->user_id; ?>)</a> <i class=" icon-large icon-ban-circle"></i></span><br />
                    <?php } else { ?>
                    <span class="v1"><a href="#"><?php echo $view->name; ?> (<?php echo $view->user_id; ?>)</a></span><br />
                    
                    <?php } ?>
                                 </div>
                                 	<div class="span12" style="margin-left:0px;">
                                    <div class="span3 view1 " style="width:150px;">
                                   
                                     <?php if($view->file_name=='')
									{ ?><img src="<?php echo base_url();?>file/img/noimg.jpg" width="150" height="150" />
                                    <?php }
									else
									{
										?>
                                    
                                    <img src="<?php echo base_url();?>uploads/<?php echo  $view->file_name; ?>"><?php } ?></div>
                            		<div class="span5" style="width:43.5%;">
                                    <div class="loader1 mclr2">
                          <p>
                                	<img src="<?php echo base_url(); ?>file/img/p1_03.jpg">   View Mobile No/sms 
                                </p>
                                <p> 
                                	<img src="<?php echo base_url(); ?>file/img/p2_03.jpg">  Request Horoscope			</p>    
                                     
                                  
                                     <div class="span12 mnn">
                                       <?php echo  $view->about_us; ?><br /> 
 <br /></div>

<div class="span12">
<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
 <?php
 if ($intrested->num_rows() >0)
 {
  foreach($intrested->result() as $intrest) {
	 $int[]=  $intrest->intrested_id;
 }}
 else
 {
 $int[]= '10000';
 }
 if (in_array($view->user_id, $int)||($int===NULL)){
		?>


       Intrest Send <?php } else {?>
         <a href="<?php echo base_url(); ?>index.php/status/intrest/<?php  echo $view->user_id; ?>" style="text-decoration:none; color:inherit;">

        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" />
        <?php }?>

<?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]=  'S2078769';
 }
 if (in_array($view->user_id, $blocked)||($blocked===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/unblock/<?php  echo $view->user_id; ?>" style="text-decoration:none; color:inherit;"> <input style="background-color:#999;"   class=" btn1 btn-small match mbtn" type="button" value="Blocked" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/block/<?php  echo $view->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" /></a>
        <?php  }?>
 
 <?php
 if ($shortlist->num_rows() >0)
 {
  foreach($shortlist->result() as $short) {
	 $shortlisted[]=  $short->shortlisted_id;
 }}
 else
 {
 $shortlisted[]=  '11111';
 }
 if (in_array($view->user_id, $shortlisted)||($shortlisted===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/shortlisted/<?php  echo $view->user_id; ?>" style="text-decoration:none; color:inherit;"> <input class="btn1 btn-small match mbtn" style="background-color:#999;" type="button" value="shortlisted" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/shortlist/<?php  echo $view->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="shortlist" /></a>
        <?php  }?>
</form>
 </span>
  <div id="toPopup10"> 
    	
        <div class="close10"></div>
       
		<div id="popup_content10"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
    
    
    
    
    
    
    
    
    <div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                 <table>
                                <tr>
                                  <td width="120px;">Profile Created For
                                    </td>
                                  <td>
                                  :&nbsp;
                                  </td>
                                  <td>
									<strong><?php echo $view->profile_for; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Age, Height
                                    </td>
                                    <td>
                                  :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $view->age; ?> Yrs, <?php echo $view->height; ?> Cms</strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Religion
                                    </td>
                                    <td>
                                 :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $view->religion_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Caste, Sub Caste</td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $view->cast_name; ?>,<?php echo $view->subcast; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Star
                                    </td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $view->star_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td valign="top">Location 
                                    </td>
                                    <td valign="top">
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $view->city; ?>, <?php echo $view->state; ?>, <?php echo $row->country; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                <tr>
                                  <td valign="top">Education
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $view->education_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                
                                <tr>
                                  <td valign="top">Occupation
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $view->occupation_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                 <tr>
                                    <td>Gender
                                    </td>
                                    <td>
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $view->gender; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                        	</table>
<br />
<a href="<?php echo base_url();?>index.php/individual/profile/<?php echo $view->user_id; ?>"><strong>View Full Profile</strong></a>
</div>
					</div>			</div>
                    
                    
                     


</div>
<?php } ?>

<div class="span12 recommends5">                                           
  <div class="span8 recommends6">
<?php if(count($viewed)>10){ ?>
<div class="span4 recommends7"><a href="<?php echo base_url(); ?>index.php/searching/viewed">
<button type="submit" style="width: 150px;" class="btn1 btn-large match">View all</button>
</a></div>
<?php } ?>
</div>     
  </div>

 		</div>
        
        <div role="tabpanel" class="tab-pane" id="shortlist">	
         <?php foreach($shortlisting->result() as $short){ ?>
    <div class="span12 mdiv " style="margin-left:0px;" >

                            	<div class="span12 prof1" style="margin-left:0px;">
                                	<div class="span12">
                             <?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]=  'S2078769';
 }
 if (in_array($short->user_id, $blocked)||($blocked===NULL)){
		?>
                    <span class="v1"><a href="#"><?php echo $short->name; ?> (<?php echo $short->user_id; ?>)</a> <i class=" icon-large icon-ban-circle"></i></span><br />
                    <?php } else { ?>
                    <span class="v1"><a href="#"><?php echo $short->name; ?> (<?php echo $short->user_id; ?>)</a></span><br />
                    
                    <?php } ?><br />
                  
                   <br />
                    
                
                                    
                                 </div>
                                 	<div class="span12" style="margin-left:0px;">
                                    <div class="span3 view1 " style="width:150px;">
                                   
                                    <?php if($short->file_name=='')
									{ ?><img class="profile_thumb" src="<?php echo base_url();?>file/img/noimg.jpg" />
                                    <?php }
									else
									{
										?>
                                    
                                    <img class="profile_thumb" src="<?php echo base_url();?>uploads/<?php echo  $short->file_name; ?>"><?php } ?></div>
                            		  <div class="span5" style=" width:43.5%;">
                                    <div class="loader1 mclr2">
                                    <p>
                                	<img src="<?php echo base_url(); ?>file/img/p1_03.jpg">   View Mobile No/sms 
                                </p>
                                <p> 
                                	<img src="<?php echo base_url(); ?>file/img/p2_03.jpg">  Request Horoscope			</p>   
                                     
                                  
                                     <div class="span12 mnn">
                                     <?php  echo $short->about_us; ?> <br /> 
 <br /></div>

<div class="span12">
<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
 
 <?php
 if ($intrested->num_rows() >0)
 {
  foreach($intrested->result() as $intrest) {
	 $int[]=  $intrest->intrested_id;
 }}
 else
 {
 $int[]= '10000';
 }
 if (in_array($short->user_id, $int)||($int===NULL)){
		?>


       Intrest Send <?php } else {?>
         <a href="<?php echo base_url(); ?>index.php/status/intrest/<?php  echo $short->user_id; ?>" style="text-decoration:none; color:inherit;">

        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" />
        <?php }?>

<?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]=  'S2078769';
 }
 if (in_array($short->user_id, $blocked)||($blocked===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/unblock/<?php  echo $short->user_id; ?>" style="text-decoration:none; color:inherit;"> <input style="background-color:#999;"   class=" btn1 btn-small match mbtn" type="button" value="Blocked" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/block/<?php  echo $short->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" /></a>
        <?php  }?>
 
 <?php
 if ($shortlist->num_rows() >0)
 {
  foreach($shortlist->result() as $shor) {
	 $shortlisted[]=  $shor->shortlisted_id;
 }}
 else
 {
 $shortlisted[]=  '11111';
 }
 if (in_array($short->user_id, $shortlisted)||($shortlisted===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/shortlisted/<?php  echo $short->user_id; ?>" style="text-decoration:none; color:inherit;"> <input class="btn1 btn-small match mbtn" style="background-color:#999;" type="button" value="shortlisted" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/shortlist/<?php  echo $short->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="shortlist" /></a>
        <?php  }?>
    
</form>
 </span>
  <div id="toPopup10"> 
    	
        <div class="close10"></div>
       
		<div id="popup_content10"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
    
    
    
    
    
    
    
    
    <div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                               <table>
                                <tr>
                                  <td width="120px;">Profile Created For
                                    </td>
                                  <td>
                                  :&nbsp;
                                  </td>
                                  <td>
									<strong><?php echo $short->profile_for; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Age, Height
                                    </td>
                                    <td>
                                  :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $short->age; ?> Yrs, <?php echo $short->height; ?> Cms</strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Religion
                                    </td>
                                    <td>
                                 :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $short->religion_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Caste, Sub Caste</td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $short->cast_name; ?>,<?php echo $short->subcast; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Star
                                    </td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $short->star_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td valign="top">Location 
                                    </td>
                                    <td valign="top">
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $short->city; ?>, <?php echo $short->state; ?>, <?php echo $row->country; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                <tr>
                                  <td valign="top">Education
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $short->education_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                
                                <tr>
                                  <td valign="top">Occupation
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $short->occupation_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                 <tr>
                                    <td>Gender
                                    </td>
                                    <td>
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $short->gender; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                        	</table>
<br />
<a href="<?php echo base_url();?>index.php/individual/profile/<?php echo $short->user_id; ?>"><strong>View Full Profile</strong></a>
</div>
					</div>			</div>
                    
                    
                     


</div>
<?php } ?>

<div class="span12 recommends5">                                           
  <div class="span8 recommends6">
<?php if(count($shortlisting)>10){ ?>
<div class="span4 recommends7"><a href="<?php echo base_url(); ?>/index.php/searching/shortlist">
<button type="submit" style="width: 150px;" class="btn1 btn-large match">View all</button>
</a></div>
<?php } ?>
</div>     
  </div>

 		</div>
        
        
        
        
        <div role="tabpanel" class="tab-pane" id="like">	
          <?php foreach($like->result() as $like){ ?>
    <div class="span12 mdiv " style="margin-left:0px;" >

                            	<div class="span12 prof1">
                                	<div class="span12">
                                    
                                    
                                    <?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]=  'S2078769';
 }
 if (in_array($like->user_id, $blocked)||($blocked===NULL)){
		?>
                    <span class="v1"><a href="#"><?php echo $like->name; ?> (<?php echo $like->user_id; ?>)</a> <i class=" icon-large icon-ban-circle"></i></span><br />
                    <?php } else { ?>
                    <span class="v1"><a href="#"><?php echo $like->name; ?> (<?php echo $like->user_id; ?>)</a></span><br />
                    
                    <?php } ?>
                                 </div>
                                 	<div class="span12" style="margin-left:0px;">
                                    <div class="span3 view1 " style="width:150px;">
                                   
                                     <?php if($like->file_name=='')
									{ ?><img src="<?php echo base_url();?>file/img/noimg.jpg" width="150" height="150" />
                                    <?php }
									else
									{
										?>
                                    
                                    <img src="<?php echo base_url();?>uploads/<?php echo  $like->file_name; ?>"><?php } ?></div>
                            		<div class="span5" style="width:43.5%">
                                    <div class="loader1 mclr2">
                                   <p>
                                	<img src="<?php echo base_url(); ?>file/img/p1_03.jpg">   View Mobile No/sms 
                                </p>
                                <p> 
                                	<img src="<?php echo base_url(); ?>file/img/p2_03.jpg">  Request Horoscope			</p>        
                                  
                                     <div class="span12 mnn">
                                      <?php  echo $like->about_us; ?> <br /> 
 <br /></div>

<div class="span12">
<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
 
 <?php
 if ($intrested->num_rows() >0)
 {
  foreach($intrested->result() as $intrest) {
	 $int[]=  $intrest->intrested_id;
 }}
 else
 {
 $int[]= '10000';
 }
 if (in_array($like->user_id, $int)||($int===NULL)){
		?>


       Intrest Send <?php } else {?>
         <a href="<?php echo base_url(); ?>index.php/status/intrest/<?php  echo $like->user_id; ?>" style="text-decoration:none; color:inherit;">

        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" />
        <?php }?>
<?php
 if ($block->num_rows() >0)
 {
  foreach($block->result() as $blk) {
	 $blocked[]=  $blk->blocked_id;
 }}
 else
 {
 $blocked[]=  'S2078769';
 }
 if (in_array($like->user_id, $blocked)||($blocked===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/unblock/<?php  echo $like->user_id; ?>" style="text-decoration:none; color:inherit;"> <input style="background-color:#999;"   class=" btn1 btn-small match mbtn" type="button" value="Blocked" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/block/<?php  echo $like->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" /></a>
        <?php  }?>
 
 <?php
 if ($shortlist->num_rows() >0)
 {
  foreach($shortlist->result() as $short) {
	 $shortlisted[]=  $short->shortlisted_id;
 }}
 else
 {
 $shortlisted[]=  '11111';
 }
 if (in_array($like->user_id, $shortlisted)||($shortlisted===NULL)){
		?>
    	<a href="<?php echo base_url(); ?>index.php/status/shortlisted/<?php  echo $like->user_id; ?>" style="text-decoration:none; color:inherit;"> <input class="btn1 btn-small match mbtn" style="background-color:#999;" type="button" value="shortlisted" /></a>
    	<?php }  else {  ?><a href="<?php echo base_url(); ?>index.php/status/shortlist/<?php  echo $like->user_id; ?>"  style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="shortlist" /></a>
        <?php  }?>
</form>
 </span>
  <div id="toPopup10"> 
    	
        <div class="close10"></div>
       
		<div id="popup_content10"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
    
    
    
    
    
    
    
    
    <div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                                 <table>
                                <tr>
                                  <td width="120px;">Profile Created For
                                    </td>
                                  <td>
                                  :&nbsp;
                                  </td>
                                  <td>
									<strong><?php echo $like->profile_for; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Age, Height
                                    </td>
                                    <td>
                                  :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $like->age; ?> Yrs, <?php echo $like->height; ?> Cms</strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Religion
                                    </td>
                                    <td>
                                 :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $like->religion_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Caste, Sub Caste</td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $like->cast_name; ?>,<?php echo $like->subcast; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td>Star
                                    </td>
                                    <td>
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $like->star_name; ?></strong>
                                    </td>
                                </tr>
                                
                                   <tr>
                                    <td valign="top">Location 
                                    </td>
                                    <td valign="top">
                                   :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $like->city; ?>, <?php echo $like->state; ?>, <?php echo $row->country; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                <tr>
                                  <td valign="top">Education
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong><?php echo $like->education_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                
                                <tr>
                                  <td valign="top">Occupation
                                    </td>
                                    <td valign="top">
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $like->occupation_name; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                                
                                 <tr>
                                    <td>Gender
                                    </td>
                                    <td>
                                    :&nbsp;
                                    </td>
                                    <td>
									<strong> <?php echo $like->gender; ?></strong>
                                    </td>
                                    
                                    
                                </tr>
                        	</table>
<br />
<a href="<?php echo base_url();?>index.php/individual/profile/<?php echo $like->user_id; ?>"><strong>View Full Profile</strong></a>
</div>
					</div>			</div>
                    
                    
                     


</div>
<?php } ?>

<div class="span12 recommends5">                                           
  <div class="span8 recommends6">
<?php if(count($like)>10){ ?>
<div class="span4 recommends7"><a href="<?php echo base_url(); ?>index.php/searching/liked">
<button type="submit" style="width: 150px;" class="btn1 btn-large match">View all</button>
</a></div>
<?php }?>
</div>     
  </div>

 		</div>
        
 </div>
 
</div> 

            			
 				<div class="span4 recommends3">                           
                            <div class="search ">
                            	<div class="span12 mpd1">
                                <h3>Search by ID</h3>
                                <div class="span11 mpd">
                                
                                <form class="navbar-form pull-left form-search">
                                <input type="text" class="form-control">
       				 <button class="btn">Search</button>
  						</form>
                            	</div>	
								
                                </div>
                              </div>
                              
                              <div class="matches">
                            	<div class="span12">
                                	<h3>Your matches</h3>
                                		<div class="span10 mbd2">
                                        	<div class="span11 mbd3">  <img src="img/images/images/my-account_03.jpg" /></div>
                                        <div class="span9 mbd4">
                                        <h4>Tharunima</h4>
                                        <h5>S189599</h5>
                                        <h5>Trichur</h5>
                                        </div>
                                        </div>
                                <div class="span5 mbd5"> 
       				<button type="submit" style="background-color:#FFF;" class="btn1 btn-large match">More</button>

                                </div>
                             
                                </div>
                                </div>
				</div>                              
       





                            
</div>
</div>
</div>                             
<?php $this->load->view('footer'); ?>
<?php }
	else
	{
		 redirect('home/', 'refresh');
	}