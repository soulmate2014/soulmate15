<?php $this->load->view('header'); ?>
<!--<script type="text/javascript" src="<?php echo base_url();?>file/js/script.js"></script>

<script type="text/javascript" src="http://code.jquery.com/jquery-2.1.3.min.js"> </script>
        <link href="<?php echo base_url();?>file/css/popup.css" rel="stylesheet" type="text/css" media="all" />-->

<div class="row-fluid recommends8">
<div class="container">
<div class="span12 ">


<div class="span8 recommends2">
 <ul class="nav nav-tabs ad mclr recommends1" role="tablist">
    <li role="presentation" class="active "><a href="#home" aria-controls="home" role="tab" data-toggle="tab" ><div class="recommends"><span> 23</span> <br />New matches</div></a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab" ><div class="recommends"><span> 85</span> <br />Yet to be viewed</div></a></li>
    <li role="presentation" ><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab" ><div class="recommends"><span> 30</span> <br />Viewed & not contacted</div></a></li>
   <li role="presentation" ><a href="#messages1" aria-controls="messages1" role="tab" data-toggle="tab" ><div class="recommends"> <span>25</span> <br />Shortlisted my profile</div></a></li>
    <li role="presentation" ><a href="#messages2" aria-controls="messages2" role="tab" data-toggle="tab" ><div class="recommends"><span> 50 </span><br />Recently updated</div></a></li>
    
  </ul>
<script>
document.getElementById("myDiv").style.marginLeft = "0px";
</script>

  <!-- Tab panes -->
  <div class="tab-content mclr1 bg">
    <div role="tabpanel" class="tab-pane active" id="home">	
    <div class="span12 mdiv " style="margin-left:0px;" >

                            	<div class="span12 prof1">
                                	<div class="span12"><input class="check " type="checkbox" /> <span class="v1 "> Sruthy</span><br />
                                 <span class="id1">  S189856</span>
                                 </div>
                                 	<div class="span12">
                                    <div class="span3 view1 ">
                                   
                                    <img src="img/images/images/message-page_03.png"/></div>
                            		<div class="span5">
                                    <div class="loader1 mclr2">
                                    	<p><img src="img/images/p1_03.jpg" />   View Mobile No/sms </p>
                                    		
                                      <p> <img src="img/images/p2_03.jpg" />  Request Horoscope</p>    
                                     
                                  
                                     <div class="span12 mnn">
                                       Lorem Ipsum is simply dummy text of the printing 
 typesetting industry. Lorem Ipsum has been the industry's standard dummy <br /> 
 <br /></div>

<div class="span12">
<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
 
 <a href="#" class="topopup11" style="text-decoration:none; color:inherit;">
        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" /></a>

 <a href="#" class="topopup12" style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" />
 
 <a href="#" class="topopup13" style="text-decoration:none; color:inherit;">
  		<input class="btn1 btn-small match mbtn" type="button" value="short list" /></a>
</form>
 </span>
  <div id="toPopup10"> 
    	
        <div class="close10"></div>
       
		<div id="popup_content10"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
    
    
    
    
    
    
    
    
    <div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                                    Profile Created for Daughter<br />
Name : Nina .P<br />
Age, Height : 21 Yrs, 5 Ft 3 In / 160 Cms<br />
Religion : Hindu<br />
Caste, Sub Caste : Ezhava<br />
Star :Rohini<br />
Location : Thrissur, Kerala, India<br />
Education: civil<br />
Occupation : Not working<br />
<br />
<a href="#">View Full Profile</a>
</div>
					</div>			</div>
                    
                    
                     


</div>


<div class="span12 mdiv " style="margin-left:0px;" >

                            	<div class="span12 prof1">
                                	<div class="span12"><input class="check " type="checkbox" /> <span class="v1 "> Sruthy</span><br />
                                 <span class="id1">  S189856</span>
                                 </div>
                                 	<div class="span12">
                                    <div class="span3 view1 ">
                                   
                                    <img src="img/images/images/message-page_03.png"/></div>
                            		<div class="span5">
                                    <div class="loader1 mclr2">
                                    	<p><img src="img/images/p1_03.jpg" />   View Mobile No/sms </p>
                                    		
                                      <p> <img src="img/images/p2_03.jpg" />  Request Horoscope</p>    
                                     
                                  
                                     <div class="span12 mnn">
                                       Lorem Ipsum is simply dummy text of the printing 
 typesetting industry. Lorem Ipsum has been the industry's standard dummy <br /> 
 <br /></div>

<div class="span12">
<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
 
 <a href="#" class="topopup11" style="text-decoration:none; color:inherit;">
        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" /></a>

 <a href="#" class="topopup12" style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" />
 
 <a href="#" class="topopup13" style="text-decoration:none; color:inherit;">
  		<input class="btn1 btn-small match mbtn" type="button" value="short list" /></a>
</form>
 </span>
  <div id="toPopup10"> 
    	
        <div class="close10"></div>
       
		<div id="popup_content10"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
    
    
    
    
    
    
    
    
    <div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                                    Profile Created for Daughter<br />
Name : Nina .P<br />
Age, Height : 21 Yrs, 5 Ft 3 In / 160 Cms<br />
Religion : Hindu<br />
Caste, Sub Caste : Ezhava<br />
Star :Rohini<br />
Location : Thrissur, Kerala, India<br />
Education: civil<br />
Occupation : Not working<br />
<br />
<a href="#">View Full Profile</a>
</div>
					</div>			</div>
                    
                    
                     


</div>
 		</div>
        
         
         
         
         
         
         <div role="tabpanel" class="tab-pane" id="profile">	
         
    <div class="span12 mdiv " style="margin-left:0px;" >

                            	<div class="span12 prof1">
                                	<div class="span12"><input class="check " type="checkbox" /> <span class="v1 "> Sruthy</span><br />
                                 <span class="id1">  S189856</span>
                                 </div>
                                 	<div class="span12">
                                    <div class="span3 view1 ">
                                   
                                    <img src="img/images/images/message-page_03.png"/></div>
                            		<div class="span5">
                                    <div class="loader1 mclr2">
                                    	<p><img src="img/images/p1_03.jpg" />   View Mobile No/sms </p>
                                    		
                                      <p> <img src="img/images/p2_03.jpg" />  Request Horoscope</p>    
                                     
                                  
                                     <div class="span12 mnn">
                                       Lorem Ipsum is simply dummy text of the printing 
 typesetting industry. Lorem Ipsum has been the industry's standard dummy <br /> 
 <br /></div>

<div class="span12">
<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
 
 <a href="#" class="topopup11" style="text-decoration:none; color:inherit;">
        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" /></a>

 <a href="#" class="topopup12" style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" />
 
 <a href="#" class="topopup13" style="text-decoration:none; color:inherit;">
  		<input class="btn1 btn-small match mbtn" type="button" value="short list" /></a>
</form>
 </span>
  <div id="toPopup10"> 
    	
        <div class="close10"></div>
       
		<div id="popup_content10"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
    
    
    
    
    
    
    
    
    <div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                                    Profile Created for Daughter<br />
Name : Nina .P<br />
Age, Height : 21 Yrs, 5 Ft 3 In / 160 Cms<br />
Religion : Hindu<br />
Caste, Sub Caste : Ezhava<br />
Star :Rohini<br />
Location : Thrissur, Kerala, India<br />
Education: civil<br />
Occupation : Not working<br />
<br />
<a href="#">View Full Profile</a>
</div>
					</div>			</div>
                    
                    
                     


</div>
<div class="span12 mdiv " style="margin-left:0px;" >

                            	<div class="span12 prof1">
                                	<div class="span12"><input class="check " type="checkbox" /> <span class="v1 "> Sruthy</span><br />
                                 <span class="id1">  S189856</span>
                                 </div>
                                 	<div class="span12">
                                    <div class="span3 view1 ">
                                   
                                    <img src="img/images/images/message-page_03.png"/></div>
                            		<div class="span5">
                                    <div class="loader1 mclr2">
                                    	<p><img src="img/images/p1_03.jpg" />   View Mobile No/sms </p>
                                    		
                                      <p> <img src="img/images/p2_03.jpg" />  Request Horoscope</p>    
                                     
                                  
                                     <div class="span12 mnn">
                                       Lorem Ipsum is simply dummy text of the printing 
 typesetting industry. Lorem Ipsum has been the industry's standard dummy <br /> 
 <br /></div>

<div class="span12">
<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
 
 <a href="#" class="topopup11" style="text-decoration:none; color:inherit;">
        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" /></a>

 <a href="#" class="topopup12" style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" />
 
 <a href="#" class="topopup13" style="text-decoration:none; color:inherit;">
  		<input class="btn1 btn-small match mbtn" type="button" value="short list" /></a>
</form>
 </span>
  <div id="toPopup10"> 
    	
        <div class="close10"></div>
       
		<div id="popup_content10"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
    
    
    
    
    
    
    
    
    <div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                                    Profile Created for Daughter<br />
Name : Nina .P<br />
Age, Height : 21 Yrs, 5 Ft 3 In / 160 Cms<br />
Religion : Hindu<br />
Caste, Sub Caste : Ezhava<br />
Star :Rohini<br />
Location : Thrissur, Kerala, India<br />
Education: civil<br />
Occupation : Not working<br />
<br />
<a href="#">View Full Profile</a>
</div>
					</div>			</div>
                    
                    
                     


</div>



 		</div>
        
        
        <div role="tabpanel" class="tab-pane" id="profile">	
    <div class="span12 mdiv ">

                            	<div class="span12 prof1">
                                	<div class="span12"><input class="check " type="checkbox" /> <span class="v1 "> melvin</span><br />
                                 <span class="id1">  S189856</span>
                                 </div>
                                 	<div class="span12">
                                    <div class="span3 view1 ">
                                   
                                    <img src="img/images/images/message-page_03.png"/></div>
                            		<div class="span5">
                                    <div class="loader1 mclr2">
                                    	<p><img src="img/images/p1_03.jpg" />   View Mobile No/sms </p>
                                    		
                                      <p> <img src="img/images/p2_03.jpg" />  Request Horoscope</p>    
                                     
                                  
                                     <div class="span12 mnn">
                                       Lorem Ipsum is simply dummy text of the printing 
 typesetting industry. Lorem Ipsum has been the industry's standard dummy <br /> 
 <br /></div>

<div class="span12">
<form action="#">
  <a href="#" class="topopup10" style="text-decoration:none; color:inherit;"> 
  		<input class="btn1 btn-small match mbtn" type="button" value="Send Mail" /></a>
 
 <a href="#" class="topopup11" style="text-decoration:none; color:inherit;">
        <input type="button" class="btn1 btn-small match mbtn" name="yes" value="Send Interest" /></a>

 <a href="#" class="topopup12" style="text-decoration:none; color:inherit;">
        <input class="btn1 btn-small match mbtn" type="button" value="block" />
 
 <a href="#" class="topopup13" style="text-decoration:none; color:inherit;">
  		<input class="btn1 btn-small match mbtn" type="button" value="short list" /></a>
</form>
 </span>
  <div id="toPopup10"> 
    	
        <div class="close10"></div>
       
		<div id="popup_content10"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr10"></div>
   	<div id="backgroundPopup10"></div>
    
    
    
    
    
    
    
    
    <div id="toPopup11"> 
    	
        <div class="close11"></div>
       
		<div id="popup_content11"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr11"></div>
   	<div id="backgroundPopup11"></div>
    
    
  
  
  
  <div id="toPopup12"> 
    	
        <div class="close12"></div>
       
		<div id="popup_content12"> <!--your content start-->
        <h2>edit mobile number</h2>
           <p>
If you wish to change your mobile number,please change and verify it
            </p>
            <div class="span4">
 <select name="profile_for" class="selectpicker select_select" style="color:#000;border-color:#991248;font-weight: 100;">
<option value="0">india(+91)</option>
			<option value="Myself">Myself</option>
			<option value="Son">Son</option>
			<option value="Daughter">Daughter</option>
			<option value="Brother">Brother</option>
			<option value="Sister">Sister</option>
			<option value="Relative">Relative</option>
			<option value="Friend">Friend</option>
  </select>  </div>  
  <div class="spann4">
   <input type="text" name=""  value="9895989598" />
  </div>       
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr12"></div>
   	<div id="backgroundPopup12"></div>
            
 
 
 
 
 <div id="toPopup13"> 
    	
        <div class="close13"></div>
       
		<div id="popup_content13"> <!--your content start-->
        
           <p>
Your interest has been sent to Nijiya Nazar (E2953987).
            </p>
            <div class="span4">
 
 				
 
 
   			</div>  
         
            <a href="#"><input type="button" class="ppbutton" value="update"/></a>
        </div> <!--your content end-->
    
    </div> <!--toPopup end-->
    
	<div class="loaderr13"></div>
   	<div id="backgroundPopup13"></div>
    
       
 		</div>
             </div>
              
                               
                                     
                                     
                                    </div>
                                    <div class="span4 view1">
                                    Profile Created for Daughter<br />
Name : Nina .P<br />
Age, Height : 21 Yrs, 5 Ft 3 In / 160 Cms<br />
Religion : Hindu<br />
Caste, Sub Caste : Ezhava<br />
Star :Rohini<br />
Location : Thrissur, Kerala, India<br />
Education: civil<br />
Occupation : Not working<br />
<br />
<a href="#">View Full Profile</a>
</div>
					</div>			</div> 


</div>

 		</div>
        
 </div>
 
</div> 

 
 
 
 
 
 
 
 
 
                 			
 				<div class="span4 recommends3">                           
                            <div class="search ">
                            	<div class="span12 mpd1">
                                <h3>Search by ID</h3>
                                <div class="span11 mpd">
                                
                                <form class="navbar-form pull-left form-search">
                                <input type="text" class="form-control">
       				 <button class="btn">Search</button>
  						</form>
                            	</div>	
								
                                </div>
                              </div>
                              
                              <div class="matches">
                            	<div class="span12">
                                	<h3>Your matches</h3>
                                		<div class="span10 mbd2">
                                        	<div class="span11 mbd3">  <img src="img/images/images/my-account_03.jpg" /></div>
                                        <div class="span9 mbd4">
                                        <h4>Tharunima</h4>
                                        <h5>S189599</h5>
                                        <h5>Trichur</h5>
                                        </div>
                                        </div>
                                <div class="span5 mbd5"> 
       				<button type="submit" style="background-color:#FFF;" class="btn1 btn-large match">More</button>

                                </div>
                             
                                </div>
                                </div>
				</div>                              
       

<div class="span12 recommends5">                                           
  <div class="span8 recommends6">

<div class="span4 recommends7"><button type="submit"  class=" recommends4">view all</button></div>

</div>     
  </div>



                            
</div>
</div>
</div>                             
<?php $this->load->view('footer'); ?>