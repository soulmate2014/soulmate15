<!DOCTYPE html>
<html>
<head>
    <title><?php echo $user_id; ?></title>
    <style type="text/css">
        body {
            text-align: center;
        }
    </style>
</head>
<body>
    <h2>Your file was successfully uploaded.Please <a href="<?php echo base_url(); ?>">Logon</a> Soulmate to continue.</h2>
    <p>
	
    </p>
</body>
</html>


