<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Soulmate</title>
<link href="<?php echo base_url();?>file/css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>file/css/bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>file/css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>file/css/style1.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link href="<?php echo base_url();?>file/css/elements.css" rel="stylesheet">
<script src="<?php echo base_url();?>file/js/my_js.js"></script>

</head>

<body>
		<div class="header"><img src="<?php echo base_url();?>file/img/about_02.png" />
    <div class="navbar-wrapper">
    		<div class="container">
               <div class="span5" data-original-title="" title=""></div>
               <div class="span3" data-original-title="" title=""><img src="<?php echo base_url();?>file/img/logo_06.png"></div>

      </div>
    </div>
   </div>
   <div class="row-fluid menu ">
    <div class="container">
    <div class="navbar">
<div class="navbar-inner">
            <div class="container freg">
            <div class="span4" data-original-title="" title=""></div>
              <h3>You are that much closer to your soulmate</h3>
              <div class="span3" data-original-title="" title=""></div>
            </div>
          </div>
          </div>
          </div>
        </div>