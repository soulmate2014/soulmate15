<?php $this->load->view('homeheader');
$this->load->view('homecontent');
$this->load->view('homefooter'); ?>