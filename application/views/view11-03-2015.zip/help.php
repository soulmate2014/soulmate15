<?php $this->load->view('header'); ?>
<link href="<?php echo base_url();?>file/css/about.css" rel="stylesheet" type="text/css" />
<style>
.offset0 {
margin-left: 53px;
margin-top: 70px;
}
</style>
<div class="row-fluid content">
<div class="container">
    <div class="span7">
<div role="tabpanel">

  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Contact Us</a></li>
    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Customer Care</a></li>
    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Feedback</a></li>
  
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">
   
    <div class="span12 first">
    <div class="span4">
    <h4 class="choose">Address1</h4>
    <img src="img/images/h1_03.jpg" />
    </div>
    <div class="span8 choose">
    <br /><br />SOULMATE MATRIMONY(Head Office)<br />
SOULMATE Corporate EKMPIN- 680258<br />
Land Phone No: 04842259685,0484258755 <br />
Mobile No: 9425225365,9446984521<br />
Email id: soulmate@gmail.com</div>
    </div>
    <div class="span12">
    <div class="span4">
    <h4 class="choose">Address2</h4>
    <img src="img/images/h1_03.jpg" />
    </div>
    <div class="span8 choose">
    <br /><br />SOULMATE MATRIMONY(Head Office)<br />
SOULMATE Corporate EKMPIN- 680258<br />
Land Phone No: 04842259685,0484258755 <br />
Mobile No: 9425225365,9446984521<br />
Email id: soulmate@gmail.com</div>
    </div>
    <div class="span12">
    <div class="span4">
    <h4 class="choose">Address3</h4>
    <img src="img/images/h1_03.jpg" />
    </div>
    <div class="span8 choose">
    <br /><br />SOULMATE MATRIMONY(Head Office)<br />
SOULMATE Corporate EKMPIN- 680258<br />
Land Phone No: 04842259685,0484258755 <br />
Mobile No: 9425225365,9446984521<br />
Email id: soulmate@gmail.com</div>
    </div>
    <div class="span12">
    <div class="span4">
    <h4 class="choose">Address4</h4>
    <img src="img/images/h1_03.jpg" />
    </div>
    <div class="span8 choose">
    <br /><br />SOULMATE MATRIMONY(Head Office)<br />
SOULMATE Corporate EKMPIN- 680258<br />
Land Phone No: 04842259685,0484258755 <br />
Mobile No: 9425225365,9446984521<br />
Email id: soulmate@gmail.com</div>
    </div>
    </div>
    <div role="tabpanel" class="tab-pane" id="profile">
     <div class="span12 choose first">
     BharatMatrimony is eager to help you find your partner at the earliest. Our customer care team will be pleased to assist you anytime you have a query. You can contact our customer care team in one of the following ways. 
     </div><div class="span12 choose">
     <div class="span6"> <img src="<?php echo base_url();?>file/img/images/map_03.png" />Place1:0-8144-99-88-77</div>
      <div class="span6"><img src="<?php echo base_url();?>file/img/images/map_03.png" />Place2 : 0-8144-99-88-77</div></div>
      <div class="span12 choose">
          <div class="span6"> <img src="<?php echo base_url();?>file/img/images/map_03.png" />Place3: 0-8144-99-88-77</div>
      <div class="span6"><img src="<?php echo base_url();?>file/img/images/map_03.png" />Place4 : 0-8144-99-88-77</div></div>
         <div class="span12 choose">
             <div class="span6"> <img src="<?php echo base_url();?>file/img/images/map_03.png" />Place5: 0-8144-99-88-77</div>
      <div class="span6"><img src="<?php echo base_url();?>file/img/images/map_03.png" />Place6 : 0-8144-99-88-77</div>
     </div>
      <div class="span5 choose1">
      To Payment Related Quiries
      </div>
      <div class="span12 choose">
             <div class="span6"> <img src="<?php echo base_url();?>file/img/images/phone_07.png" />Toll Free NO
              <h4>0-8144-99-88-77</h4></div>
      <div class="span6"><div class="span3"><img src="<?php echo base_url();?>file/img/images/p1_10.png" /></div>
      Give us your contact details, <br />
we will call you back

</div>
<div class="span6" data-original-title="" title="">
     <br /> 	<form class="form-inline">
             <input type="text" class="input-small email" placeholder="Name">
             
               <input type="password" class="input-small email" placeholder="Phone No">
               <button type="submit" class="btn-small btn">Submit</button>
 		</form>
               </div> </div>

    
      
    </div>
    <div role="tabpanel" class="tab-pane" id="messages">
    <div class="span12 choose first">
    Feel free to post your comments & suggestions .We are eager to assist <br />
you to serve you better. <br /><br />
All Fields Are Mandotory.
</div>
   <div class="span12 choose">
 
     <br /> 	<form>
              <div class="span12 first" >  <div class="span6" > <input type="text" class="input-large email" placeholder="Name">
          </div>
              <div class="span6" >    <input type="password" class="input-large email" placeholder="Phone No"></div></div>
              <div class="span12" > 
                <div class="span6" > <input type="text" class="input-large email" placeholder="Matrimony ID">
          </div>
           <div class="span6" >    <textarea rows="4" name="message"></textarea></div>
              </div><div class="span12" > 
              <div class="span6" >    <input type="password" class="input-large email" placeholder="Priority"></div>
                       <div class="span6" >
               <button type="submit" class="btn-small btn">Submit</button>
 		</form></div>
               </div>
               </div>
    </div>

  </div>

</div>

  <div role="tabpanel" class="tab-pane fade" id="messages">...</div>
  <div role="tabpanel" class="tab-pane fade" id="settings">...</div>
</div>


<div class="span4 abtreg">
    <h2>REGISTER NOW</h2>
    <div class="text-center">
     <div class="span12"><div class="control-group">
    
    <div class="controls">
 
    <select name="profile_for" class="selectpicker">
<option value="0">Select Matrimony Profile for</option>
			<option value="1">Myself</option>
			<option value="2">Son</option>
			<option value="3">Daughter</option>
			<option value="4">Brother</option>
			<option value="5">Sister</option>
			<option value="6">Relative</option>
			<option value="7">Friend</option>
  </select>
    </div>
  </div></div>
     <div class="span12 ">
     <div class="controls">
    <select name="day" class="selectpicker day" >
    <option value="0">DD</option>
  <option value='01'>01</option>
<option value='02'>02</option>
<option value='03'>03</option>
<option value='04'>04</option>
<option value='05'>05</option>
<option value='06'>06</option>
<option value='07'>07</option>
<option value='08'>08</option>
<option value='09'>09</option>
<option value='10'>10</option>
<option value='11'>11</option>
<option value='12'>12</option>
<option value='13'>13</option>
<option value='14'>14</option>
<option value='15'>15</option>
<option value='16'>16</option>
<option value='17'>17</option>
<option value='18'>18</option>
<option value='19'>19</option>
<option value='20'>20</option>
<option value='21'>21</option>
<option value='22'>22</option>
<option value='23'>23</option>
<option value='24'>24</option>
<option value='25'>25</option>
<option value='26'>26</option>
<option value='27'>27</option>
<option value='28'>28</option>
<option value='29'>29</option>
<option value='30'>30</option>
<option value='31'>31</option>
  </select>
  <select name="month" class="selectpicker day">
  <option>MM</option>
 <option value='01'>January</option>
<option value='02'>February</option>
<option value='03'>March</option>
<option value='04'>April</option>
<option value='05'>May</option>
<option value='06'>June</option>
<option value='07'>July</option>
<option value='08'>August</option>
<option value='09'>September</option>
<option value='10'>October</option>
<option value='11'>November</option>
<option value='12'>December</option>
  </select>
 <select name="year" class="selectpicker day">
  <option>YYYY</option>
   	<option value="2007">2014</option>
	<option value="2006">2013</option>
	<option value="2005">2012</option>
	<option value="2004">2011</option>
	<option value="2003">2010</option>
	<option value="2002">2009</option>
   <option value="2008">2008</option>
	<option value="2007">2007</option>
	<option value="2006">2006</option>
	<option value="2005">2005</option>
	<option value="2004">2004</option>
	<option value="2003">2003</option>
	<option value="2002">2002</option>
	<option value="2001">2001</option>
	<option value="2000">2000</option>
	<option value="1999">1999</option>
	<option value="1998">1998</option>
	<option value="1997">1997</option>
	<option value="1996">1996</option>
	<option value="1995">1995</option>
	<option value="1994">1994</option>
	<option value="1993">1993</option>
	<option value="1992">1992</option>
	<option value="1991">1991</option>
	<option value="1990">1990</option>
	<option value="1989">1989</option>
	<option value="1988">1988</option>
	<option value="1987">1987</option>
	<option value="1986">1986</option>
	<option value="1985">1985</option>
	<option value="1984">1984</option>
	<option value="1983">1983</option>
	<option value="1982">1982</option>
	<option value="1981">1981</option>
	<option value="1980">1980</option>
	<option value="1979">1979</option>
	<option value="1978">1978</option>
	<option value="1977">1977</option>
	<option value="1976">1976</option>
	<option value="1975">1975</option>
	<option value="1974">1974</option>
	<option value="1973">1973</option>
	<option value="1972">1972</option>
	<option value="1971">1971</option>
	<option value="1970">1970</option>
	<option value="1969">1969</option>
	<option value="1968">1968</option>
	<option value="1967">1967</option>
	<option value="1966">1966</option>
	<option value="1965">1965</option>
	<option value="1964">1964</option>
	<option value="1963">1963</option>
	<option value="1962">1962</option>
	<option value="1961">1961</option>
	<option value="1960">1960</option>
	<option value="1959">1959</option>
	<option value="1958">1958</option>
	<option value="1957">1957</option>
	<option value="1956">1956</option>
	<option value="1955">1955</option>
	<option value="1954">1954</option>
	<option value="1953">1953</option>
	<option value="1952">1952</option>
	<option value="1951">1951</option>
	<option value="1950">1950</option>
	<option value="1949">1949</option>
	<option value="1948">1948</option>
	<option value="1947">1947</option>
	<option value="1946">1946</option>
	<option value="1945">1945</option>
	<option value="1944">1944</option>
	<option value="1943">1943</option>
	<option value="1942">1942</option>
	<option value="1941">1941</option>
	<option value="1940">1940</option>
	<option value="1939">1939</option>
	<option value="1938">1938</option>
	<option value="1937">1937</option>
	<option value="1936">1936</option>
	<option value="1935">1935</option>
	<option value="1934">1934</option>
	<option value="1933">1933</option>
	<option value="1932">1932</option>
	<option value="1931">1931</option>
	<option value="1930">1930</option>
	<option value="1929">1929</option>
	<option value="1928">1928</option>
	<option value="1927">1927</option>
	<option value="1926">1926</option>
	<option value="1925">1925</option>
	<option value="1924">1924</option>
	<option value="1923">1923</option>
	<option value="1922">1922</option>
	<option value="1921">1921</option>
	<option value="1920">1920</option>
	<option value="1919">1919</option>
	<option value="1918">1918</option>
	<option value="1917">1917</option>
	<option value="1916">1916</option>
	<option value="1915">1915</option>
	<option value="1914">1914</option>
	<option value="1913">1913</option>
	<option value="1912">1912</option>
	<option value="1911">1911</option>
	<option value="1910">1910</option>
	<option value="1909">1909</option>
	<option value="1908">1908</option>
	<option value="1907">1907</option>
	<option value="1906">1906</option>
	<option value="1905">1905</option>
	<option value="1904">1904</option>
	<option value="1903">1903</option>
	<option value="1902">1902</option>
	<option value="1901">1901</option>
	<option value="1900">1900</option>
  </select>
    </div></div>
     <div class="span12 ">
     	<div class="control-group">
    
      <input type="text" name="mobile" id="inputEmail" placeholder="mobile number" >
    </div>
  </div>
     
     <div class="span12 ">
     <div class="control-group">
   
    <div class="controls">
      <input type="text" id="inputEmail" placeholder="name">
    </div>
  </div>
     </div>
     <div class="span12 ">
     	<div class="control-group">
    <div class="controls">
    <select class="selectpicker" placeholder="Select Religion">
   <option value="0" selected="">Select Religion</option>
   <option value="1">Hindu</option>
   <option value="2">Muslim - Shia</option>
   <option value="3">Muslim - Sunni</option>
   <option value="4">Muslim - Others</option>
   <option value="5">Christian - Catholic</option>
   <option value="6">Christian - Orthodox</option>
   <option value="7">Christian - Protestant</option>
   <option value="8">Christian - Others</option>
   <option value="9">Sikh</option>
   <option value="10">Jain - Digambar</option>
   <option value="11">Jain - Shwetambar</option>
   <option value="12">Jain - Others</option>
   <option value="13">Parsi</option>
   <option value="14">Buddhist</option>
   <option value="15">Inter-Religion</option>
   <option value="16">No Religious Belief</option>
  
  </select>
    </div>
  </div>
     </div>
     <div class="span12 ">
     	 <div class="control-group">
    
    <div class="controls">
      <input type="text" id="inputEmail" placeholder="email">
    </div>
    </div>
  </div>
  <div class="span12">
  <div class="control-group">
   
   
           
    		 <div class="controls">
   
     
     <label class="radio-inline" for="inputEmail">GENDER :
  <input type="radio" name="gender" id="inlineRadio1" style=" margin-right:5px;" class="radio1" value="male">MALE
  <input type="radio" name="gender" id="inlineRadio2" style="margin-left:10px; margin-right:5px;" class="radio1" value="female">FEMALE
</label>

</div>
  
  </div>
  
  </div>
  <div class="span12 ">
  <div class="control-group">
    
    <div class="controls">
    <select name="cast" class="selectpicker" placeholder="cast" >
    <option></option>
    <option>Mustard</option>
    <option>Ketchup</option>
    <option>Relish</option>
  </select>
    </div>
  </div>
  </div>
  <div class="span12 "> 
 		<div class="control-group">
    
    <div class="controls">
      <input name="password" type="password" id="inputEmail" placeholder="password">
    </div>
  </div>
  </div> 
   <div class="span12 butten"><div class="control-group"> <div class="controls"><button type="submit" style="background-color:#FFF;" class="btn1 btn-large">REGISTER FREE</button>

   
    
      
    </div>
  </div></div>
  </div>
  </div>
</div>




<script>
  $(function () {
    $('#myTab a:last').tab('show')
  })
</script>

<script type="text/javascript">
  (function($) {
      fakewaffle.responsiveTabs(['xs', 'sm']);
  })(jQuery);
  $('#myTab a').click(function (e) {
  e.preventDefault()
  $(this).tab('show')
})
</script>
    </div>
  
          

  <div class="row-fluid footer">
           <div class="container">
    <div class="span6 footer_manu feutured1">
           <a href="#">HOME</a> / 
           <a href="#">ABOUTUS</a> /
            <a href="#">MY ACCOUNT</a> /
             <a href="#">REGISTER</a> / 
             <a href="#">SEARCH</a>  / 
             <a href="#">UP GRADE</a> / 
             <a href="#">CONTACT US</a> / 
             <a href="#">HELP</a>
             </div>
             <div class="span3"></div>
             <div class="span3 feutured1"> <div class="span4"><label class="control-label" for="inputEmail">FOLLOW US </label></div>
                               <ul> <li><a href="#"><img src="<?php echo base_url();?>file/img/images/facebook_25.jpg"></a></li>
                                <li><a href="#"><img src="<?php echo base_url();?>file/img/images/twitter_25.jpg"></a></li>
                                <li><a href="#"><img src="<?php echo base_url();?>file/img/images/google_25.jpg"></a></li> </ul>
                              
                            </div>
             </div>
             </div>
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="<?php echo base_url();?>file/js/bootstrap.js"></script>
        
        
        
</body>
</html>