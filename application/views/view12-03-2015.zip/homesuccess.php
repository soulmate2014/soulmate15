<?php $this->load->view('homeheader');
$this->load->view('homecontent_success');
$this->load->view('homefooter'); ?>