  <div class="row-fluid footer">
           <div class="container">
    <div class="span6 footer_manu feutured1">
           <a href="#">HOME</a> / 
           <a href="#">ABOUTUS</a> /
            <a href="#">MY ACCOUNT</a> /
             <a href="#">REGISTER</a> / 
             <a href="#">SEARCH</a>  / 
             <a href="#">UP GRADE</a> / 
             <a href="#">CONTACT US</a> / 
             <a href="#">HELP</a>
             </div>
             <div class="span3"></div>
             <div class="span3 feutured1"> <div class="span4"><label class="control-label" for="inputEmail">FOLLOW US </label></div>
                               <ul> <li><a href="#"><img src="<?php echo base_url();?>file/img/images/facebook_25.jpg"></a></li>
                                <li><a href="#"><img src="<?php echo base_url();?>file/img/images/twitter_25.jpg"></a></li>
                                <li><a href="#"><img src="<?php echo base_url();?>file/img/images/google_25.jpg"></a></li> </ul>
                              
                            </div>
             </div>
             </div>
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
  </body>
</html>