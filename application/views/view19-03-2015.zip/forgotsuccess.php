<?php $this->load->view('profile_header'); ?>
<div class="row-fluid content">
	<div class="container">
<h3>Suceesfully changed your password.  please logon<a href="http://zillionit.org/soulmate/" style="text-decoration:none; color:#710000;"> SOULMATE</a></h3>
</div>
</div>
