<form enctype="multipart/form-data" action="<?php echo base_url()?>index.php/gallery" method="post">
 
    <div id="boxtop"></div><div id="boxmid">
 
        <div class="section">
            <span>File:</span>
            <input type="file" name="file_data" />
        </div>
 
    </div><div id="boxbot"></div>
 
    
    <div class="text" style="float: right;">
 
    <input type="submit" value="Upload" name="upload" class="submit" />
</div>
<br style="clear:both; height: 0px;" />
 
</form>