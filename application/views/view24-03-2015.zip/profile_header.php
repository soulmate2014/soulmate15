<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Soulmate</title>
<link href="<?php echo base_url();?>file/css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>file/css/bootstrap-responsive.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>file/css/styleh.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>file/css/baseh.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>file/css/style.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>file/css/style1.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link href="<?php echo base_url();?>file/css/elements.css" rel="stylesheet">
<script src="<?php echo base_url();?>file/js/my_js.js"></script>
<script src="<?php echo base_url();?>file/js/jquery-1.9.1.min.js"></script>
</head>

<body>
		<div class="header">
    <div class="navbar-wrapper">
    		<div class="container">
               <div class="span5" data-original-title="" title=""></div>
               <div class="span3" data-original-title="" title=""><img src="<?php echo base_url(); ?>file/img/images/lg_03.png" /></div>

      </div>
    </div>
   </div>
   