<?php 
$this->load->view('homecontent');
 ?>