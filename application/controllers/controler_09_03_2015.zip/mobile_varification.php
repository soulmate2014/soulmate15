<?php
class mobile_varification extends CI_Controller {

function index()
{
	$this->load->view('mobile_varification');
}



function varification1()
{
	$data['otp']=$this->input->post('otp');
	$data['user_id']=$this->input->post('user_id');
	$data['mobile']=$this->input->post('mobile');
	$this->load->model('mobile_model');

	$data1['result']=$this->mobile_model->varification($data);
	$data1['user_id']=$this->input->post('user_id');
	$data1['email']=$this->input->post('email');
	$data1['mobile']=$this->input->post('mobile');
	
	$this->mobile_model->deleteotp($data);
	$this->mobile_model->updateotp($data);
	if($data1['result']->num_rows()>0)
	{
		$this->mobile_model->updateotp();
		$this->load->model('complete_reg_model');
		$this->load->model('search_model');
		$data1['list']=$this->complete_reg_model->getCountry();
		$data1['country']=$this->search_model->get_country();
		$this->load->view('registration',$data1);
	}
	else
	{
		$data1['error']="your Mobile number not varified please add correct OTP";
	$this->load->view('mobile_varification',$data1);
	}
	}
}
?>