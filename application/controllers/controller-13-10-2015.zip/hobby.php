<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class hobby extends CI_Controller {
	public function __construct() {
	parent::__construct();
	$this->load->model('hobby_model');
	$this->load->helper("url");

}
function index()
{
	$this->load->view('hobby');
	
}
 function daily()
 {
	 $this->load->view('daily_recomand');
 }

function insert_hobby()
{
	$hobby=$this->input->post('hobby');
	$intrest=$this->input->post('intrest');
	$fav_reads=$this->input->post('fav_reads');
	$fav_musics=$this->input->post('fav_musics');
	$preferd_movies=$this->input->post('preferd_movies');
	$sports=$this->input->post('sports');
	$fav_cousin=$this->input->post('fav_cousin');
	$fav_dress=$this->input->post('fav_dress');
	$fav_languages=$this->input->post('fav_languages');
	$data['user_id']=$this->input->post('user_id');
	$data['hobby']=implode(',',$hobby);
	$data['intrest']=implode(',',$intrest);
	$data['fav_reads']=implode(',',$fav_reads);
	$data['fav_musics']=implode(',',$fav_musics);
	$data['preferd_movies']=implode(',',$preferd_movies);
	$data['sports']=implode(',',$sports);
	$data['fav_cousin']=implode(',',$fav_cousin);
	$data['fav_dress']=implode(',',$fav_dress);
	$data['fav_languages']=implode(',',$fav_languages);
	$this->load->model('hobby_model');
	$this->hobby_model->insert($data);
	
	$this->load->view('upload_success');
}
}
?>