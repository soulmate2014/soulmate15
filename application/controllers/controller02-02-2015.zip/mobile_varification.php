<?php
class mobile_varification extends CI_Controller {

function index()
{
	$this->load->view('mobile_varification');
}



function varification1()
{
	$data['otp']=$this->input->post('otp');
	$data['user_id']=$this->input->post('user_id');
	$data['mobile']=$this->input->post('mobile');
	$this->load->model('mobile_model');

	$data1['result']=$this->mobile_model->varification($data);
	$data1['user_id']=$this->input->post('user_id');
	$data1['email']=$this->input->post('user_id');
	$data1['mobile']=$this->input->post('mobile');
	
	$this->mobile_model->deleteotp($data);
	$this->mobile_model->updateotp($data);
	if($data1['result']->num_rows()>0)
	{
		$this->mobile_model->updateotp();
		$this->load->view('profile_pic_upload',$data1);
	}
	else
	{
		$data1['error']="your Mobile number not varified please add correct OTP";
	$this->load->view('mobile_varification',$data1);
	}
	}
}
?>