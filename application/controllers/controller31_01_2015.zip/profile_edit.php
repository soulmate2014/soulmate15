<?php
class profile_edit extends CI_Controller {
public function __construct() {
parent::__construct();
$this->load->model('profile_edit_model');
}
function index()
{
	$data = array(
		'about_us' => $this->input->post('about_us'),
		'uid' => $this->input->post('uid')
		);
		$this->profile_edit_model->form_update_myself();
		redirect('login');
}
function basic()
{
	$data = array(
		'profile_for' => $this->input->post('profile_for'),
		'weight' => $this->input->post('weight'),
		'name' => $this->input->post('name'),
		'day' => $this->input->post('day'),
		'month' => $this->input->post('month'),
		'year' => $this->input->post('year'),
		'height' => $this->input->post('height'),
		'mother_tongue' => $this->input->post('mother_tongue')
	);
		$data['body_type']=$this->input->post('body_type');
		$this->load->model('profile_edit_model');
		$this->profile_edit_model->form_update_basic($data);
		redirect('login');
}
function religious()
{
$data = $_POST;

$this->load->model('profile_edit_model');
$this->profile_edit_model->form_update_religion($data);
redirect('login');
}

}
?>