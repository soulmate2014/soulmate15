<?php
class searching extends CI_Controller {
public function __construct() {
parent::__construct();
$this->load->model('search_model');
$this->load->helper("url");
$this->load->library("pagination");
}
function index()
{
	#$data['country']=$this->search_model->get_country();
	$data['result']=$this->search_model->get_country();
	$data['list']=$this->search_model->getCountry();
	$this->load->view('search',$data);
	
}

function searchresult()
{
	$this->load->view('searchresult');
}

public function printing() {
	$data['result']=$this->search_model->printing();
	$this->load->view('welcome_message',$data);
	}
function search()
{
	$data['query'] = $this->search_model->get_search();
	$this->load->view('searchres', $data);
}
public function search_id() {
		$config["base_url"] = base_url() . "index.php/searching/search_id";
		$config["total_rows"] = $this->search_model->record_count();
		$config["per_page"] = 5;
		$config["uri_segment"] = 3;
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'previous';
 
		$this->pagination->initialize($config);
 
		$page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
		$data["results"] = $this->search_model->get_countries($config["per_page"], $page);
		
		#echo print_r($data["results"]);
		$data['count']=$config["total_rows"];
		$data["links"] = $this->pagination->create_links();
 
		$this->load->view("searchresult", $data);
	}
#function search_id()
#{
#$data['query'] = $this->search_model->get_search_id();
#$data['count'] = count($this->search_model->get_search_id());
/* foreach($query as $item):
$data['year']=$item->year;

$data['month']=$item->month;

 endforeach;


$this->load->helper('date');
	  $year=$data['year'];
	  $month=$data['month'];
	# $day=$data['day'];
      $year_diff  = date("Y") - $year;
    $month_diff = date("m") - $month;
   #$day_diff   = date("d") - $day;
if ($month_diff < 0)
{
    $year_diff=$year_diff-1;
}
    #return $year_diff;

$data['age']=$year_diff;*/
 
 #$this->load->view('searchresult', $data);
#}

public function search_regular() {

		$config["base_url"] = base_url() . "index.php/searching/search_regular";
		$config["total_rows"] = $this->search_model->record_regular_count();
		$config["per_page"] = 5;
		$config["uri_segment"] = 3;
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'previous';
 	if (count($_GET) > 0) $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
 
		$page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
		$data["results"] = $this->search_model->get_regular_search($config["per_page"], $page);
		$data['count']=$config["total_rows"];
		$data["links"] = $this->pagination->create_links();
 
		$this->load->view("searchresult", $data);

	}
	
	
	public function search_advanced() {

		$config["base_url"] = base_url() . "index.php/searching/search_advanced";
		$config["total_rows"] = $this->search_model->record_advanced_count();
		$config["per_page"] = 5;
		$config["uri_segment"] = 3;
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'previous';
 	if (count($_GET) > 0) $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
 
		$page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
		$data["results"] = $this->search_model->get_advanced_search($config["per_page"], $page);
		$data['count']=$config["total_rows"];
		$data["links"] = $this->pagination->create_links();
 
		$this->load->view("searchresult", $data);

	}
	
	public function loadData()
	{
		$loadType=$_POST['loadType'];
		$loadId=$_POST['loadId'];
		$this->load->model('search_model');
		$result=$this->search_model->getData($loadType,$loadId);
		$HTML="";
		
		if($result->num_rows() > 0){
			foreach($result->result() as $list){
				$HTML.="<option value='".$list->cast_id."'>".$list->cast_name."</option>";
			}
		}
		echo $HTML;
	}

}
?>
