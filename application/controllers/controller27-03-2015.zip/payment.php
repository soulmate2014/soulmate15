<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class payment extends CI_Controller {
	public function __construct() {
	parent::__construct();
	$this->load->model('search_model');
	$this->load->helper("url");

}
function index()
{
	$this->load->view('payment');
}

		/*		  3month  		6 month			9month
                    
Start up	:		10			11				12
Standerd	:		13			14				15
premium		:		16			17				18
prime		:		19			20
Soulmate sp	:		21*/
function paymentcalculate()
{
	$package=$this->input->post('package');
	$addonhighlite=$this->input->post('addon1');
	$addonastro=$this->input->post('addon2');
	#echo $addonhighlite;
	#echo $addonastro;
	/*if($addonhighlite=='1000')
	{
	$data= array(
    'amount1' => $this->input->post('addon1'),
    'add1' => 'Profile Heighliter'
);
	}
	
	
	if($addonastro=='2000')
	{
	$data= array(
    'amount2' => $this->input->post('addon2'),
    'add2' => 'Astro Match'
);
	}*/
	
	if($package=="10")
	{
	$data= array(
    'amount' => $this->input->post('p1'),
    'package' => 'Start Up',
    'month' => '3 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	
	
	if($package=="11")
	{
		
		$data= array(
    'amount' => $this->input->post('p2'),
    'package' => 'Start Up',
    'month' => '6 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	if($package=="12")
	{
		
		$data= array(
    'amount' => $this->input->post('p3'),
    'package' => 'Start Up',
    'month' => '9 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	if($package=="13")
	{
		
		$data= array(
    'amount' => $this->input->post('p4'),
    'package' => 'Standard',
    'month' => '3 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	if($package=="14")
	{
		
		$data= array(
    'amount' => $this->input->post('p5'),
    'package' => 'Standard',
    'month' => '6 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	if($package=="15")
	{
		
		$data= array(
    'amount' => $this->input->post('p6'),
    'package' => 'Standard',
    'month' => '9 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	if($package=="16")
	{
		
		$data= array(
    'amount' => $this->input->post('p7'),
    'package' => 'premium',
    'month' => '3 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	if($package=="17")
	{
		
		$data= array(
    'amount' => $this->input->post('p8'),
    'package' => 'premium',
    'month' => '6 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	if($package=="18")
	{
		
		$data= array(
    'amount' => $this->input->post('p9'),
    'package' => 'premium',
    'month' => '9 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	
	
	if($package=="19")
	{
		
		$data= array(
    'amount' => $this->input->post('p10'),
    'package' => 'prime',
    'month' => '3 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	
	if($package=="20")
	{
		
		$data= array(
    'amount' => $this->input->post('p11'),
    'package' => 'prime',
    'month' => '6 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	
	if($package=="21")
	{
		
		$data= array(
    'amount' => $this->input->post('p12'),
    'package' => 'soulmate special',
    'month' => '18 Months',
	'add1' => $addonhighlite,
	'add2' => $addonastro
);
	}
	
	$data["total"]=$data['amount'] +$data['add1'] +$data['add2'];
	
/*	if($addonhighlite=='100')
	{
		$data= array(
    'amount1' => $this->input->post('p13'),
    'addon1' => 'Profile highliter'
);
	}
	else
	{
		$data= array(
    'amount1' => '0'
);
	}
	
	
	if(isset($addonastro))
	{
		$data= array(
    'amount2' => $this->input->post('p14'),
    'addon2' => 'Astromatcher'
);
	}
	else
	{
		$data= array(
    'amount2' => '0'
);
	}
	$data['total']=$data['amount']+$data['amount1']+$data['amount2'];*/
	#$data['addon']=$addonhighlit + $addonastro;
	#$data['total']=$data['amount'];
	#print_r($data['total']);
	$this->load->view('paymentcheckout',$data);
	
	
}
}