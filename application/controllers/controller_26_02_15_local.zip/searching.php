<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class searching extends CI_Controller {
public function __construct() {
parent::__construct();
$this->load->model('search_model');
$this->load->helper("url");
$this->load->library("pagination");
}
function index()
{
	#$data['country']=$this->search_model->get_country();
	$data['result']=$this->search_model->get_country();
	$data['list']=$this->search_model->getCountry();
	$this->load->view('search',$data);
	
}

function searchresult()
{
	$this->load->view('searchresult');
}

public function printing() {
	$data['result']=$this->search_model->printing();
	$this->load->view('welcome_message',$data);
	}
function search()
{
	$data['query'] = $this->search_model->get_search();
	$this->load->view('searchres', $data);
}
public function search_id() {
		$config["base_url"] = base_url() . "index.php/searching/search_id";
		$config["total_rows"] = $this->search_model->record_count();
		$config["per_page"] = 5;
		$config["uri_segment"] = 3;
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'previous';
 
		$this->pagination->initialize($config);
 
		$page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
		$data["results"] = $this->search_model->get_countries($config["per_page"], $page);
		
		#echo print_r($data["results"]);
		$data['count']=$config["total_rows"];
		$data["links"] = $this->pagination->create_links();
 
		$this->load->view("searchresult", $data);
	}

public function search_regular() {

		$config["base_url"] = base_url() . "index.php/searching/search_regular";
		$config["total_rows"] = $this->search_model->record_regular_count();
		$config["per_page"] = 5;
		$config["uri_segment"] = 3;
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'previous';
 	if (count($_GET) > 0) $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
 
		$page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
		$data["results"] = $this->search_model->get_regular_search($config["per_page"], $page);
		
		$data['count']=$config["total_rows"];
		$data["links"] = $this->pagination->create_links();
		$session_data = $this->session->userdata('logged_in');
 $data['email']=$session_data['username'];
		$this->load->view("searchresult", $data);

	}
	
	
	public function search_advanced() {

		$config["base_url"] = base_url() . "index.php/searching/search_advanced";
		$config["total_rows"] = $this->search_model->record_advanced_count();
		$config["per_page"] = 5;
		$config["uri_segment"] = 3;
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'previous';
 	if (count($_GET) > 0) $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
 
		$page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
		$data["results"] = $this->search_model->get_advanced_search($config["per_page"], $page);
		$data['count']=$config["total_rows"];
		$data["links"] = $this->pagination->create_links();
 
		$this->load->view("searchresult", $data);

	}
	
	public function newmatches_all() {

		$config["base_url"] = base_url() . "index.php/searching/newmatches_all";
		$config["total_rows"] = $this->search_model->record_newmatches_count();
		$config["per_page"] = 15;
		$config["uri_segment"] = 3;
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'previous';
 	if (count($_GET) > 0) $config['suffix'] = '?' . http_build_query($_GET, '', "&");
            $config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);
		$this->pagination->initialize($config);
 
		$page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
		$data["results"] = $this->search_model->get_newmatches_all($config["per_page"], $page);
		$data['count']=$config["total_rows"];
		$data["links"] = $this->pagination->create_links();
 
		$this->load->view("searchresult", $data);

	}
	
	
	public function loadData()
	{
		$loadType=$_POST['loadType'];
		$loadId=$_POST['loadId'];
		$this->load->model('search_model');
		$result=$this->search_model->getData($loadType,$loadId);
		$HTML="";
		
		if($result->num_rows() > 0){
			foreach($result->result() as $list){
				$HTML.="<option value='".$list->cast_id."'>".$list->cast_name."</option>";
			}
		}
		echo $HTML;
	}
	
	
	public function loadData2()
	{
		$loadType=$_POST['loadType'];
		$loadId=$_POST['loadId'];
		$this->load->model('search_model');
		$result2=$this->search_model->getData2($loadType,$loadId);
		$HTML="";
		
		if($result->num_rows() > 0){
			foreach($result2->result() as $list){
				$HTML.="<option value='".$list->cast_id."'>".$list->cast_name."</option>";
			}
		}
		echo $HTML;
	}


}
?>
