<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class staticcontent extends CI_Controller {
 
 function __construct()
 {
	 
   parent::__construct();
    $this->load->model('search_model');
  
 }
 
 function contact(){
	  $data['list']=$this->search_model->getCountry();
		#$data['result']=$this->search_model->get_country();
		$data['country']=$this->search_model->get_country();
		$this->load->model('homemodel');
		$data['profile_highlight']=$this->homemodel->profile();
		$data['prime']=$this->homemodel->prime();
		$data['mother']=$this->homemodel->mother_tongue();
		$data['allcast']=$this->homemodel->cast();
		$data['success']=$this->homemodel->success();
	 $this->load->view('contact',$data);
	 
 }
 
 function help(){
	
	 $data['list']=$this->search_model->getCountry();
		#$data['result']=$this->search_model->get_country();
		$data['country']=$this->search_model->get_country();
		$this->load->model('homemodel');
		$data['profile_highlight']=$this->homemodel->profile();
		$data['prime']=$this->homemodel->prime();
		$data['mother']=$this->homemodel->mother_tongue();
		$data['allcast']=$this->homemodel->cast();
		$data['success']=$this->homemodel->success();
	 $this->load->view('help',$data);
	 
 }
 function about(){
	  $data['list']=$this->search_model->getCountry();
		#$data['result']=$this->search_model->get_country();
		$data['country']=$this->search_model->get_country();
		$this->load->model('homemodel');
		$data['profile_highlight']=$this->homemodel->profile();
		$data['prime']=$this->homemodel->prime();
		$data['mother']=$this->homemodel->mother_tongue();
		$data['allcast']=$this->homemodel->cast();
		$data['success']=$this->homemodel->success();
	 $this->load->view('about',$data);
	 
 }
  function faq(){
	  $data['list']=$this->search_model->getCountry();
		#$data['result']=$this->search_model->get_country();
		$data['country']=$this->search_model->get_country();
		$this->load->model('homemodel');
		$data['profile_highlight']=$this->homemodel->profile();
		$data['prime']=$this->homemodel->prime();
		$data['mother']=$this->homemodel->mother_tongue();
		$data['allcast']=$this->homemodel->cast();
		$data['success']=$this->homemodel->success();
	 $this->load->view('faq',$data);
	 
 }
 
}