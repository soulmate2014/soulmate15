<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class upload_video extends CI_Controller {
	
	function index()
	{
		$this->load->view('video_upload');
		
	}
	
	
	function do_upload()
	{
		$this->load->helper(array('form', 'url'));
		$config['upload_path'] = './video/';
$config['allowed_types'] = 'flv|mp4|avi|mpeg';   
$config['max_size'] = '2028'; // whatever you need
$config['max_width']          = '';
$config['max_height']          = '';
$config['file_name']="soul_vid_".uniqid(rand(1,100000));

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload())
		{
			$error = array('error' => $this->upload->display_errors());

			$this->load->view('managevideos', $error);
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());

			redirect("upload_video");
		}
	}
 
}

?>