<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class staticcontent extends CI_Controller {
 
 function __construct()
 {
   parent::__construct();
  
 }
 
 function contact(){
	 $this->load->view('contact');
	 
 }
 
 function help(){
	 $this->load->view('help');
	 
 }
 function about(){
	 $this->load->view('about');
	 
 }
 
}