<?php
class complete_reg_model extends CI_Model{
function __construct() {
parent::__construct();
}
public function form_update($data1) {
$this->load->database();
$this->db->where(array('email' => $this->input->post('email')));
$this->db->update('registration', $data1); 

} 
public function otpstatus($otpdata) {
$this->load->database();
$this->db->insert('smsotp', $otpdata); 
}
function getCountry(){
		$this->db->select('iso3,country_name');
		$this->db->from('country');
		$this->db->order_by('country_name', 'asc'); 
		$query=$this->db->get();
		return $query; 
	}
function getData($loadType,$loadId){
		if($loadType=="state"){
			$fieldList='state_name as name';
			$table='state';
			$fieldName='iso3';
			$orderByField='state_name';						
		}else{
			$fieldList='city_name as name';
			$table='city';
			$fieldName='city_state';
			$orderByField='city_name';	
		}
		
		$this->db->select($fieldList);
		$this->db->from($table);
		$this->db->where($fieldName, $loadId);
		$this->db->order_by($orderByField, 'asc');
		$query=$this->db->get();
		return $query; 
	}
}
?>