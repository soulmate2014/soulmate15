<?php
class partner_pref_model extends CI_Model{
function __construct() {
parent::__construct();
}
public function form_update($data1) {
$this->load->database();
$this->db->insert('partners_pref', $data1);
#echo $this->db->last_query();
} 
}
?>             