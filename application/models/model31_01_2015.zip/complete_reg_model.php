<?php
class complete_reg_model extends CI_Model{
function __construct() {
parent::__construct();
}
public function form_update($data1) {
$this->load->database();
$this->db->where(array('email' => $this->input->post('email')));
$this->db->update('registration', $data1); 
} 
}
?>             