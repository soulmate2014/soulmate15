<?php class individual_model extends CI_Model{

public function profile($email) 
{
	$this->load->database();
	 $this -> db -> select('*');
   $this -> db -> from('registration');
$this -> db -> where('email', $email);
   $query = $this -> db -> get();
   return $query;
}
}