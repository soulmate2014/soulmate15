<?php
class myhome_model extends CI_Model{
function myhome($user) {
	
$this->load->database();
	 $this -> db -> select('*');
   $this -> db -> from('registration');
   $this->db->join ( 'partners_pref', 'partners_pref.user_id = registration.user_id' , 'left' );
	$this->db->join ( 'country', 'country.iso3 = registration.country' , 'left' );
	$this->db->join ( 'state', 'state.stateID = registration.state' , 'left' );
	$this->db->join ( 'mother_tongue', 'mother_tongue.mother_id = registration.mother_tongue' , 'left' );
	$this->db->join ( 'cast', 'cast_id = registration.cast' , 'left' );
	$this->db->join ( 'religions', 'religions.religion_id = registration.religion' , 'left' );
	$this->db->join ( 'star', 'star.star_id = registration.star' , 'left' );
	$this->db->join ( 'education', 'education.education_id = registration.education', 'left' );
	$this->db->join ( 'occupation', 'occupation.occupation_id = registration.occupation', 'left' );
	$this->db->join ( 'currency', 'currency.id_currency = registration.inc_currency', 'left' );
	$this->db->where_not_in('user_id',$user);
	/* */
	
   #$where = "email='$username' OR user_id='username' AND password='active'";
   #$this -> db -> where('email', $username);

   $query = $this -> db -> get();
/*   echo  $this->db->last_query();
*/    $this->db->last_query();
   return $query;
	
	}
}
?>